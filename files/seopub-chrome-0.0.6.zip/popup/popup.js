// ===================================================
// SEO Publisher -Ezz — Popup Logic v1.4
// ===================================================

// ── State ─────────────────────────────────────────
const state = {
  platform: 'salla',
  mode: 'articles',
  sallaUi: 'new',
  sheetData: [],
  headers: [],
  mapping: {},
  mappings: {},
  images: {},
  detectedTabs: null,
  items: [],
  notReady: [],
  selected: new Set(),
  job: null,
  watching: false,
  renderedLog: { id: null, count: 0 },
};

// ── Helpers ───────────────────────────────────────
const $ = (id) => document.getElementById(id);

const STEP_OF = { 'screen-setup': 1, 'screen-mapping': 2, 'screen-preview': 3, 'screen-publishing': 4, 'screen-done': 4 };

const show = (screenId) => {
  const already = $(screenId).classList.contains('active');
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  $(screenId).classList.add('active');
  const step = STEP_OF[screenId] || 1;
  document.querySelectorAll('#steps li').forEach(li => {
    const n = Number(li.dataset.step);
    li.classList.toggle('done', n < step);
    li.classList.toggle('current', n === step);
    if (n === step) li.setAttribute('aria-current', 'step'); else li.removeAttribute('aria-current');
  });
  if (!already) window.scrollTo(0, 0);
};

function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'text') el.textContent = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const charLen = (s) => [...(s || '')].length;

function showError(id, msg) {
  const el = $(id);
  el.textContent = msg;
  el.classList.remove('hidden');
}

function hideError(id) { $(id).classList.add('hidden'); }

function setBusy(btn, busyText) {
  if (busyText) { btn.dataset.label = btn.textContent; btn.textContent = busyText; btn.disabled = true; }
  else { btn.textContent = btn.dataset.label || btn.textContent; btn.disabled = false; }
}

async function send(msg) {
  try { return await chrome.runtime.sendMessage(msg); }
  catch (e) { return { ok: false, error: 'SEOPub could not reach its background script. Reload the extension and try again.' }; }
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ── Job types ─────────────────────────────────────
const PRODUCT_FIELDS = (store) => [
  { key: 'newName', label: 'New product name', optional: true, hint: 'Only if you want to rename it.', kw: ['new name', 'الاسم الجديد', 'اسم جديد'] },
  { key: 'name', label: 'Product name', prefer: 'current', hint: `The current name in ${store}. It has to match exactly.`, kw:['product name', 'اسم المنتج', 'المنتج', 'name', 'الاسم'] },
  { key: 'metaTitle', label: 'Meta title', optional: true, kw: ['meta title', 'seo title', 'عنوان'] },
  { key: 'metaDesc', label: 'Meta description', optional: true, kw: ['meta desc', 'seo desc', 'description', 'وصف'] },
  { key: 'slug', label: 'SEO link (slug)', optional: true, hint: 'A full product link works too.', kw: ['slug', 'url', 'رابط المنتج'] },
  { key: 'doc', label: 'Description doc', optional: true, noneLabel: 'Keep current description', hint: 'A Google Doc with the product description.', kw: ['doc', 'رابط الوصف', 'رابط'] },
];

const ARTICLE_FIELDS = (withSnippet) => [
  { key: 'keyword', label: 'Keyword', hint: 'Used as the article title and its link, and to match cover images.', kw: ['keyword', 'الكلمة المفتاحية', 'كلمة'] },
  { key: 'title', label: 'Meta title', optional: true, noneLabel: 'Leave empty', kw: ['meta title', 'title', 'عنوان المقال', 'عنوان'] },
  { key: 'desc', label: 'Meta description', optional: true, noneLabel: 'Leave empty', kw: ['meta desc', 'description', 'desc', 'الوصف القصير', 'وصف'] },
  { key: 'doc', label: 'Article doc', hint: 'A Google Doc with the article body.', kw: ['doc', 'رابط المحتوى', 'رابط'] },
  ...(withSnippet ? [{ key: 'snippet', label: 'Snippet', optional: true, noneLabel: 'No snippet', hint: 'A short summary shown in the blog list.', kw: ['snippet', 'excerpt', 'ملخص', 'مقتطف'] }] : []),
];

function buildArticle(get) {
  const keyword = get('keyword');
  if (!keyword) return null;
  const slug = toSlug(keyword);
  return {
    name: keyword, keyword, slug,
    metaTitle: get('title'), metaDesc: get('desc'), docUrl: get('doc'), snippet: get('snippet'),
    image: state.images[slug] || null,
  };
}

function buildProduct(get) {
  const productName = get('name');
  if (!productName) return null;
  return {
    name: productName, productName,
    newName: get('newName'), metaTitle: get('metaTitle'), metaDesc: get('metaDesc'),
    slug: get('slug'), docUrl: get('doc'),
  };
}

function articleReason(a) {
  if (!a.image) return 'No cover image';
  if (!a.docUrl) return 'No doc link';
  return null;
}

const SALLA_TITLE_MAX = 70;

const TYPES = {
  'salla:articles': {
    one: 'article', many: 'articles', verb: 'Publish', path: 'blog',
    fields: () => ARTICLE_FIELDS(false),
    hint: 'SEOPub opens the Salla editor for each article and saves it as a draft.',
    build: buildArticle, reason: articleReason,
  },
  'zid:articles': {
    one: 'article', many: 'articles', verb: 'Publish', path: 'blog',
    fields: () => ARTICLE_FIELDS(true),
    hint: 'Articles are created as unpublished in Zid. Keep your store open in a Zid dashboard tab.',
    cut: { title: 70, desc: 127 },
    build: buildArticle, reason: articleReason,
  },
  'salla:products': {
    one: 'product', many: 'products', verb: 'Update', path: 'products',
    fields: () => PRODUCT_FIELDS('Salla'),
    hint: 'SEOPub finds each product by its current name and changes only the columns you pick.',
    build: buildProduct,
    reason: (p) => {
      if (charLen(p.metaTitle) > SALLA_TITLE_MAX) return `Meta title is ${charLen(p.metaTitle)} characters. Salla allows up to ${SALLA_TITLE_MAX}`;
      return state.sallaUi === 'new'
        ? (productHasWork(p) ? null : 'Nothing to update')
        : (p.metaTitle ? null : 'Classic needs a meta title');
    },
  },
  'zid:products': {
    one: 'product', many: 'products', verb: 'Update', path: 'products',
    fields: () => PRODUCT_FIELDS('Zid'),
    hint: 'SEOPub finds each product by its current name and changes only the columns you pick. Keep your store open in a Zid dashboard tab.',
    cut: { title: 70, desc: 160 },
    build: buildProduct,
    reason: (p) => productHasWork(p) ? null : 'Nothing to update',
  },
};

const typeKey = () => `${state.platform}:${state.mode}`;
const currentType = () => TYPES[typeKey()];
const storeLabel = (platform) => platform === 'zid' ? 'Zid' : 'Salla';

// ── Platform Selector ─────────────────────────────
function setSeg(attr, value) {
  document.querySelectorAll(`[data-${attr}]`).forEach(b => {
    const on = b.dataset[attr.replace(/-(\w)/g, (_, c) => c.toUpperCase())] === value;
    b.classList.toggle('active', on);
    b.setAttribute('aria-pressed', String(on));
  });
}

document.querySelectorAll('[data-platform]').forEach(btn => {
  btn.addEventListener('click', () => {
    state.platform = btn.dataset.platform;
    chrome.storage.local.set({ platform: state.platform });
    syncSetup();
  });
});

// ── Mode Selector ─────────────────────────────────
document.querySelectorAll('[data-mode]').forEach(btn => {
  btn.addEventListener('click', () => {
    state.mode = btn.dataset.mode;
    chrome.storage.local.set({ mode: state.mode });
    syncSetup();
  });
});

document.querySelectorAll('[data-salla-ui]').forEach(btn => {
  btn.addEventListener('click', () => {
    state.sallaUi = btn.dataset.sallaUi;
    chrome.storage.local.set({ sallaUi: state.sallaUi });
    syncSetup();
  });
});

function syncSetup() {
  document.body.dataset.store = state.platform;
  setSeg('platform', state.platform);
  setSeg('mode', state.mode);
  setSeg('salla-ui', state.sallaUi);
  $('salla-ui-wrap').classList.toggle('hidden', !(state.platform === 'salla' && state.mode === 'products'));
  $('images-section').classList.toggle('hidden', state.mode !== 'articles');
  refreshStoreStatus();
  renderLastRun();
}

// ── Store status ──────────────────────────────────
async function refreshStoreStatus() {
  const box = $('store-status');
  const text = $('store-status-text');
  const openBtn = $('btn-open-store');
  let ok = false, msg = '';
  try {
    if (state.platform === 'zid') {
      const id = await getZidStoreId();
      ok = !!id;
      msg = ok ? `Zid store ${id} is open in a tab.` : 'Open your store in the Zid dashboard and log in.';
    } else {
      const tabs = await chrome.tabs.query({ url: 'https://s.salla.sa/*' });
      ok = tabs.length > 0;
      msg = ok ? 'The Salla dashboard is open in a tab.' : 'Open the Salla dashboard and log in.';
    }
  } catch (e) {
    msg = 'Could not check your store tabs.';
  }
  box.classList.toggle('ok', ok);
  box.classList.toggle('warn', !ok);
  text.textContent = msg;
  openBtn.classList.toggle('hidden', ok);
}

$('btn-open-store').addEventListener('click', () => {
  chrome.tabs.create({ url: state.platform === 'zid' ? 'https://dashboard.zid.sa/' : 'https://s.salla.sa/' });
});

let statusTimer = null;
const queueStatus = () => { clearTimeout(statusTimer); statusTimer = setTimeout(refreshStoreStatus, 400); };
chrome.tabs.onUpdated.addListener((_id, info) => { if (info.url || info.status === 'complete') queueStatus(); });
chrome.tabs.onRemoved.addListener(queueStatus);

// ── Images ────────────────────────────────────────
$('img-input').addEventListener('change', (e) => handleImages(e.target.files));
const dropZone = $('img-drop-zone');
dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  handleImages(e.dataTransfer.files);
});

function handleImages(fileList) {
  Array.from(fileList || []).forEach(f => {
    const slug = toSlug(f.name.replace(/\.[^.]+$/, ''));
    if (slug) state.images[slug] = f;
  });
  renderImageCount();
}

function renderImageCount() {
  const count = Object.keys(state.images).length;
  $('img-count').classList.toggle('hidden', count === 0);
  $('img-count-text').textContent = `${plural(count, 'image', 'images')} ready`;
}

$('btn-clear-images').addEventListener('click', () => {
  state.images = {};
  $('img-input').value = '';
  renderImageCount();
});

// ── CSV Parser ─────────────────────────────────────
function parseCSVFull(text) {
  const rows = [];
  let cur = "";
  let inQ = false;
  let row = [];

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const next = text[i + 1];

    if (inQ) {
      if (c === '"' && next === '"') {
        cur += '"';
        i++;
      } else if (c === '"') {
        inQ = false;
      } else {
        cur += c;
      }
    } else {
      if (c === '"') {
        inQ = true;
      } else if (c === ',') {
        row.push(cur.trim());
        cur = "";
      } else if (c === '\n') {
        row.push(cur.trim());
        cur = "";
        rows.push(row);
        row = [];
      } else if (c === '\r') {
        // تجاهل \r في \r\n
      } else {
        cur += c;
      }
    }
  }

  if (cur.trim() || row.length) {
    row.push(cur.trim());
    if (row.some(c => c)) rows.push(row);
  }

  return rows;
}

function parseCSV(text) {
  const rows = parseCSVFull(text);
  if (rows.length < 2) return { headers: [], rows: [] };
  const headers = rows[0];
  const result = rows.slice(1)
    .filter(r => r.some(c => c.trim()))
    .map(cols => {
      const obj = {};
      headers.forEach((h, i) => (obj[h] = (cols[i] || "").trim()));
      return obj;
    });
  return { headers, rows: result };
}

// ── Sheet tabs ────────────────────────────────────
function resetTabPicker() {
  state.detectedTabs = null;
  $('tab-select').classList.add('hidden');
  $('tab-name-manual').classList.add('hidden');
  $('tab-default').classList.remove('hidden');
  const url = $('sheet-url').value;
  $('tab-default').textContent = /[#&?]gid=\d+/.test(url) ? 'The tab in your link' : 'First tab';
}

$('sheet-url').addEventListener('input', resetTabPicker);

// ── Detect Tabs ───────────────────────────────────
$('btn-detect-tabs').addEventListener('click', async () => {
  const url = $('sheet-url').value.trim();
  if (!url) return showError('setup-error', 'Paste your Google Sheet link first.');
  hideError('setup-error');
  const btn = $('btn-detect-tabs');
  setBusy(btn, 'Finding');
  const res = await send({ type: 'LIST_SHEET_TABS', url });
  setBusy(btn);
  $('tab-default').classList.add('hidden');
  if (!res?.ok || res.fallback || !res.tabs?.length) {
    $('tab-select').classList.add('hidden');
    $('tab-name-manual').classList.remove('hidden');
    $('tab-name-manual').focus();
    if (!res?.ok) showError('setup-error', res?.error || 'Could not list the tabs. Type the tab name instead.');
    return;
  }
  state.detectedTabs = res.tabs;
  $('tab-select').replaceChildren(...res.tabs.map((t, i) => h('option', { value: i, text: t.name })));
  $('tab-select').classList.remove('hidden');
  $('tab-name-manual').classList.add('hidden');
});

// ── Recent sheets ─────────────────────────────────
async function rememberSheet(url) {
  const { recentSheets = [] } = await chrome.storage.local.get('recentSheets');
  const list = [url, ...recentSheets.filter(u => u !== url)].slice(0, 6);
  await chrome.storage.local.set({ recentSheets: list, sheetUrl: url });
  renderRecent(list);
}

function renderRecent(list) {
  $('recent-sheets').replaceChildren(...list.map(u => h('option', { value: u })));
}

// ── Load Sheet ────────────────────────────────────
$('btn-load').addEventListener('click', async () => {
  const url = $('sheet-url').value.trim();
  if (!url) return showError('setup-error', 'Paste your Google Sheet link first.');
  hideError('setup-error');
  let tabName = null, gid = null;
  if (state.detectedTabs && !$('tab-select').classList.contains('hidden')) {
    const chosen = state.detectedTabs[parseInt($('tab-select').value)];
    if (chosen) { tabName = chosen.name; gid = chosen.gid; }
  } else if (!$('tab-name-manual').classList.contains('hidden')) {
    tabName = $('tab-name-manual').value.trim() || null;
  }

  const btn = $('btn-load');
  setBusy(btn, 'Loading sheet');
  const res = await send({ type: 'FETCH_SHEET', url, tabName, gid });
  setBusy(btn);
  if (!res?.ok) return showError('setup-error', res?.error || 'The sheet did not load. Check the link and the sharing settings.');

  const { headers, rows } = parseCSV(res.csv);
  if (!headers.length) return showError('setup-error', 'This tab is empty, or its first row has no column names.');

  state.sheetData = rows;
  state.headers = headers;
  await rememberSheet(url);
  renderMapping();
  show('screen-mapping');
});

// ── Mapping ───────────────────────────────────────
const NEW_HINTS = ['new', 'جديد', 'مقترح'];
const CURRENT_HINTS = ['current', 'old', 'حالي', 'قديم'];
const hasAny = (h, list) => list.some(w => h.includes(w));
const columnKind = (header) => {
  const lc = (header || '').toLowerCase();
  const isNew = hasAny(lc, NEW_HINTS), isCurrent = hasAny(lc, CURRENT_HINTS);
  return isNew && !isCurrent ? 'new' : isCurrent && !isNew ? 'current' : null;
};
const wrongKind = (f, header) => {
  const kind = columnKind(header);
  return kind !== null && kind !== (f.prefer === 'current' ? 'current' : 'new');
};

function detectColumns(fields, headers, saved) {
  const used = new Set();
  const picks = {};
  if (saved) {
    for (const f of fields) {
      if (!(f.key in saved)) continue;
      if (saved[f.key] === null && f.optional) { picks[f.key] = -1; continue; }
      if (wrongKind(f, saved[f.key])) continue;
      const idx = headers.indexOf(saved[f.key]);
      if (idx >= 0) { picks[f.key] = idx; used.add(idx); }
    }
  }
  const lower = headers.map(h => h.toLowerCase().trim());
  for (const f of fields) {
    if (f.key in picks) continue;
    const [want, avoid] = f.prefer === 'current' ? [CURRENT_HINTS, NEW_HINTS] : [NEW_HINTS, CURRENT_HINTS];
    let best = -1, score = 0;
    lower.forEach((h, i) => {
      if (used.has(i)) return;
      const bias = (hasAny(h, want) ? 10 : 0) - (hasAny(h, avoid) ? 10 : 0);
      f.kw.forEach((k, rank) => {
        const kk = k.toLowerCase();
        const base = h === kk ? 100 - rank : h.includes(kk) ? 50 - rank : 0;
        const s = base > 0 ? base + bias : 0;
        if (s > score) { score = s; best = i; }
      });
    });
    if (best >= 0) { picks[f.key] = best; used.add(best); }
    else picks[f.key] = f.optional ? -1 : 0;
  }
  return picks;
}

function sampleFor(idx) {
  if (idx < 0) return '';
  const hdr = state.headers[idx];
  const row = state.sheetData.find(r => r[hdr]);
  return row ? row[hdr] : '';
}

function renderMapping() {
  const type = currentType();
  const fields = type.fields();
  const picks = detectColumns(fields, state.headers, state.mappings[typeKey()]);
  $('sheet-summary').textContent = `${plural(state.sheetData.length, 'row', 'rows')} and ${plural(state.headers.length, 'column', 'columns')} loaded.`;
  $('mapping-hint').textContent = type.hint;
  hideError('mapping-error');

  const order = ['name', 'newName', 'metaTitle', 'metaDesc', 'slug', 'doc', 'keyword', 'title', 'desc', 'snippet'];
  const sorted = [...fields].sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key));

  $('mapping-fields').replaceChildren(...sorted.map(f => {
    const opts = [
      f.optional ? h('option', { value: -1, text: f.noneLabel || 'Leave unchanged' }) : null,
      ...state.headers.map((hd, i) => h('option', { value: i, text: hd || `Column ${i + 1}` })),
    ];
    const select = h('select', { id: `map-${f.key}`, class: 'select' }, opts);
    select.value = String(picks[f.key]);
    const sample = h('p', { class: 'sample', dir: 'auto' });
    const warn = h('p', { class: 'map-warn hidden' });
    const paint = () => {
      const idx = parseInt(select.value);
      const v = sampleFor(idx);
      sample.textContent = v ? `First value: ${v}` : '';
      const bad = idx >= 0 && wrongKind(f, state.headers[idx]);
      warn.textContent = bad
        ? (f.prefer === 'current'
          ? 'This looks like a column of new values. SEOPub searches the store with this value, so it has to be the name the product has now.'
          : 'This looks like a column of current values. SEOPub sends this column to the store, so the product would get its old text back.')
        : '';
      warn.classList.toggle('hidden', !bad);
    };
    select.addEventListener('change', paint);
    paint();
    return h('div', { class: 'map-row' },
      h('label', { for: `map-${f.key}` }, h('span', { text: f.label }), f.optional ? h('span', { class: 'opt', text: 'Optional' }) : null),
      select,
      sample,
      warn,
      f.hint ? h('p', { class: 'hint', text: f.hint }) : null,
    );
  }));
}

$('btn-mapping-back').addEventListener('click', () => show('screen-setup'));

// ── Save Mappings ─────────────────────────────────
$('btn-save-mapping').addEventListener('click', async () => {
  const fields = currentType().fields();
  const mapping = {};
  const saved = {};
  for (const f of fields) {
    const idx = parseInt($(`map-${f.key}`).value);
    mapping[f.key] = idx;
    saved[f.key] = idx >= 0 ? state.headers[idx] : null;
  }
  const required = fields.filter(f => !f.optional).map(f => mapping[f.key]);
  if (new Set(required).size !== required.length) {
    return showError('mapping-error', 'Two required fields use the same column. Pick a different column for one of them.');
  }
  state.mapping = mapping;
  state.mappings[typeKey()] = saved;
  await chrome.storage.local.set({ mappings: state.mappings });
  buildPreview();
  show('screen-preview');
});

// ── Previews ──────────────────────────────────────
function buildPreview() {
  const type = currentType();
  const headers = state.headers;
  state.items = [];
  state.notReady = [];
  const seen = new Set();
  state.sheetData.forEach(row => {
    const get = (key) => {
      const idx = state.mapping[key];
      return idx >= 0 && idx !== undefined ? (row[headers[idx]] || '').trim() : '';
    };
    const item = type.build(get);
    if (!item) return;
    const key = normName(item.name);
    const reason = seen.has(key) ? 'Duplicate row' : type.reason(item);
    seen.add(key);
    if (reason) state.notReady.push({ item, reason });
    else state.items.push(item);
  });
  state.selected = new Set(state.items);
  $('preview-filter').value = '';
  hideError('preview-error');
  renderPreview();
}

function countEl(text, limit, cut) {
  const n = charLen(text);
  const over = n > limit;
  const label = cut && n > cut ? `${n}, cut to ${cut}` : `${n}/${limit}`;
  return h('span', { class: `count${over ? ' over' : ''}`, title: over ? `Google usually shows about ${limit} characters` : null, text: label });
}

function serpCard(item, type) {
  const cut = type.cut || {};
  const isProduct = state.mode === 'products';
  const slug = isProduct ? cleanProductSlug(item.slug) : item.slug;
  const urlText = slug ? `${type.path} › ${slug}` : `${type.path} › link unchanged`;
  const titleText = item.metaTitle;
  const descText = item.metaDesc;
  const tags = [];
  if (isProduct) {
    if (item.newName) tags.push(h('span', { class: 'tag' }, 'Rename to ', h('bdi', { text: item.newName })));
    tags.push(h('span', { class: 'tag', text: item.docUrl ? 'Description from doc' : 'Description unchanged' }));
  } else {
    tags.push(h('span', { class: 'tag' }, 'Image: ', h('bdi', { text: item.image.name })));
    if (item.snippet) tags.push(h('span', { class: 'tag', text: 'Snippet' }));
  }
  if (!titleText) tags.push(h('span', { class: `tag${isProduct ? '' : ' warn'}`, text: isProduct ? 'Meta title unchanged' : 'No meta title' }));

  const box = h('input', { type: 'checkbox', 'aria-label': `Include ${item.name}` });
  box.checked = state.selected.has(item);
  const rtl = /[֐-ࣿ]/.test(`${item.name}${titleText}`);
  const card = h('label', { class: `serp${box.checked ? '' : ' off'}` },
    box,
    h('div', { class: 'serp-body', dir: rtl ? 'rtl' : 'ltr' },
      h('div', { class: 'serp-name', text: item.name }),
      h('div', { class: 'serp-url', text: urlText }),
      h('div', { class: 'serp-line' },
        h('div', { class: titleText ? 'serp-title' : 'serp-title serp-empty', text: titleText || 'No meta title' }),
        titleText ? countEl(titleText, 60, cut.title) : null),
      h('div', { class: 'serp-line' },
        h('div', { class: descText ? 'serp-desc' : 'serp-desc serp-empty', text: descText || 'No meta description' }),
        descText ? countEl(descText, 160, cut.desc) : null),
      h('div', { class: 'tags' }, tags),
    ),
  );
  box.addEventListener('change', () => {
    if (box.checked) state.selected.add(item); else state.selected.delete(item);
    card.classList.toggle('off', !box.checked);
    renderCounts();
  });
  return card;
}

function visibleItems() {
  const q = normName($('preview-filter').value);
  return q ? state.items.filter(i => normName(i.name).includes(q)) : state.items;
}

function renderPreview() {
  const type = currentType();
  const visible = visibleItems();
  $('preview-list').replaceChildren(...(visible.length
    ? visible.map(i => serpCard(i, type))
    : [h('p', { class: 'empty', text: state.items.length ? 'No rows match this filter.' : `No ${type.many} are ready. Check the skipped rows below, or go back and change the columns.` })]));

  $('skipped-wrap').classList.toggle('hidden', state.notReady.length === 0);
  $('skipped-summary').textContent = `${plural(state.notReady.length, 'row', 'rows')} skipped`;
  $('skipped-list').replaceChildren(...state.notReady.map(({ item, reason }) =>
    h('li', {}, h('span', { dir: 'auto', text: item.name }), h('span', { text: reason }))));
  renderCounts();
}

function renderCounts() {
  const type = currentType();
  const n = state.selected.size;
  $('review-counts').replaceChildren(
    h('strong', { text: String(n) }), ` of ${plural(state.items.length, type.one, type.many)} selected`);
  const vis = visibleItems();
  const visOn = vis.filter(i => state.selected.has(i)).length;
  $('chk-all').checked = vis.length > 0 && visOn === vis.length;
  $('chk-all').indeterminate = visOn > 0 && visOn < vis.length;
  $('chk-all').disabled = vis.length === 0;
  $('btn-publish').textContent = `${type.verb} ${plural(n, type.one, type.many)}`;
  $('btn-publish').disabled = n === 0;
}

$('chk-all').addEventListener('change', (e) => {
  visibleItems().forEach(i => { if (e.target.checked) state.selected.add(i); else state.selected.delete(i); });
  renderPreview();
});

$('preview-filter').addEventListener('input', renderPreview);

// ── Publish Router ────────────────────────────────
$('btn-back').addEventListener('click', () => show('screen-mapping'));

$('btn-publish').addEventListener('click', async () => {
  const type = currentType();
  const btn = $('btn-publish');
  hideError('preview-error');
  setBusy(btn, 'Starting');
  const chosen = state.items.filter(i => state.selected.has(i));
  let items;
  try {
    items = await Promise.all(chosen.map(async ({ image, ...rest }) => image
      ? { ...rest, imageBase64: await fileToBase64(image), imageName: image.name }
      : rest));
  } catch (e) {
    setBusy(btn);
    return showError('preview-error', 'Could not read one of the cover images. Add them again and retry.');
  }
  const skipped = [
    ...state.notReady.map(({ item, reason }) => ({ name: item.name, reason })),
    ...state.items.filter(i => !state.selected.has(i)).map(i => ({ name: i.name, reason: 'Not selected' })),
  ];
  const res = await send({
    type: 'JOB_START',
    spec: { key: typeKey(), sallaUi: state.sallaUi, store: storeLabel(state.platform), one: type.one, many: type.many, verb: type.verb, items, skipped },
  });
  setBusy(btn);
  renderCounts();
  if (!res?.ok) return showError('preview-error', res?.error || 'The run did not start.');
  state.watching = true;
  await refreshJob();
});

$('btn-stop').addEventListener('click', async () => {
  setBusy($('btn-stop'), 'Stopping after this one');
  await send({ type: 'JOB_STOP' });
});

$('btn-restart').addEventListener('click', () => {
  state.watching = false;
  state.items = []; state.notReady = [];
  syncSetup();
  show('screen-setup');
});

$('btn-view-last').addEventListener('click', () => {
  state.watching = true;
  renderJob(state.job);
});

// ── Job view ──────────────────────────────────────
const STATUS_LABEL = { ok: 'Done', warn: 'Done, check it', error: 'Failed', stopped: 'Not run', skipped: 'Skipped' };
const STATUS_MARK = { ok: '✓', warn: '!', error: '✕', stopped: '○', skipped: '○' };
const STATUS_ORDER = { error: 0, stopped: 1, warn: 2, ok: 3, skipped: 4 };

function formatEta(ms) {
  if (ms < 60000) return 'Under a minute left';
  const m = Math.round(ms / 60000);
  return m === 1 ? 'About 1 minute left' : `About ${m} minutes left`;
}

function jobCounts(job) {
  const rs = job.results.filter(Boolean);
  return {
    ok: rs.filter(r => r.status === 'ok' || r.status === 'warn').length,
    failed: rs.filter(r => r.status === 'error').length,
    notRun: rs.filter(r => r.status === 'stopped').length,
  };
}

async function refreshJob() {
  const res = await send({ type: 'JOB_GET' });
  state.job = res?.job || null;
  if (state.job && (state.job.status === 'running' || !state.job.seen)) state.watching = true;
  if (state.watching) renderJob(state.job);
  renderLastRun();
}

function renderLastRun() {
  const job = state.job;
  const bar = $('last-run');
  if (!job || state.watching) { bar.classList.add('hidden'); return; }
  const c = jobCounts(job);
  const when = new Date(job.finishedAt || job.startedAt).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
  $('last-run-text').textContent = job.status === 'running'
    ? `A run in ${job.store} is in progress.`
    : `Last run in ${job.store}, ${when}: ${c.ok} done, ${c.failed} failed.`;
  bar.classList.remove('hidden');
}

function renderJob(job) {
  if (!job) { state.watching = false; show('screen-setup'); return; }
  document.body.dataset.store = job.key.split(':')[0];
  if (job.status === 'running') renderRunning(job);
  else renderDone(job);
}

function renderRunning(job) {
  document.body.classList.add('running');
  const total = job.batchTotal || job.items.length;
  const done = job.batchDone || 0;
  $('pub-header-label').textContent = `${job.verb === 'Publish' ? 'Publishing' : 'Updating'} ${plural(total, job.one, job.many)} in ${job.store}`;
  $('progress-fill').style.width = total ? `${Math.round((done / total) * 100)}%` : '0%';
  $('progress-label').textContent = `${done} of ${total}`;
  $('progress-eta').textContent = done && done < total ? formatEta(((Date.now() - job.batchStarted) / done) * (total - done)) : '';

  const logEl = $('pub-log');
  const r = state.renderedLog;
  if (r.id !== job.id || job.log.length < r.count) { logEl.replaceChildren(); r.id = job.id; r.count = 0; }
  const atBottom = logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 40;
  job.log.slice(r.count).forEach(line => logEl.append(h('div', { class: `log-${line.type}`, dir: 'auto', text: line.text })));
  r.count = job.log.length;
  if (atBottom) logEl.scrollTop = logEl.scrollHeight;

  const stop = $('btn-stop');
  if (job.stopRequested) { stop.disabled = true; stop.textContent = 'Stopping after this one'; }
  else { stop.disabled = false; stop.textContent = 'Stop after this one'; }
  show('screen-publishing');
}

function jobRows(job) {
  return [
    ...job.items.map((it, i) => ({ idx: i, name: it.name, ...(job.results[i] || { status: 'stopped', note: 'Not run' }) })),
    ...job.skipped.map(s => ({ idx: -1, name: s.name, status: 'skipped', note: s.reason })),
  ];
}

const live = { jobId: null, links: {}, results: {} };

const liveFor = (job) => (live.jobId === job.id ? live : { links: {}, results: {} });
const linkOf = (job, i) => job.results[i]?.link || liveFor(job).links[i] || '';
const liveTargets = (job) => job.items.map((_, i) => i).filter(i => ['ok', 'warn'].includes(job.results[i]?.status));
const sentItem = (job, i) => {
  const r = job.results[i] || {};
  const slug = r.slug || r.note?.match(/saved as (\S+)$/)?.[1];
  return slug ? { ...job.items[i], slug } : job.items[i];
};
const forgetFailedLookups = () => {
  Object.keys(live.links).forEach(i => { if (!live.links[i]) delete live.links[i]; });
};
const canLiveCheck = (job) => job.key === 'salla:products' && job.status === 'done' && liveTargets(job).length > 0;

function liveText(r) {
  if (!r) return '';
  if (r.error) return `Website check: ${r.error}`;
  if (r.issues.length) return `Different on the website: ${r.issues.map(x => `${x.what} is "${x.got || 'missing'}"`).join(' · ')}`;
  return `On the website: ${r.checked.join(', ')} match`;
}

async function saveLive() {
  try { await chrome.storage.local.set({ liveCheck: { jobId: live.jobId, links: live.links, results: live.results } }); } catch (e) {}
}

function safeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return s; }
}

const flat = (s) => (s || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim();

async function findStoreLink(job, i) {
  const item = job.items[i];
  let id = job.results[i]?.productId || null;
  let link = '';
  if (!id) {
    const query = item.newName || item.productName;
    const target = normName(query);
    for (let page = 1; page <= 5 && !id; page++) {
      const r = await send({ type: 'SALLA_SEARCH_PRODUCTS', query, page });
      if (!r?.ok) throw new Error(`Salla search failed (${r?.error || 'no response'})`);
      const list = Array.isArray(r.data?.data) ? r.data.data : [];
      const hits = list.filter(p => normName(p.name) === target);
      if (hits.length > 1) throw new Error('more than one product in Salla has this name');
      if (hits.length) { id = hits[0].id; link = storefrontUrl(hits[0]); }
      const pg = r.data?.pagination || {};
      if ((pg.totalPages || pg.total_pages || 1) <= page) break;
    }
    if (!id) throw new Error('this product was not found in Salla under its new name');
  }
  if (!link) {
    const r = await send({ type: 'SALLA_GET_PRODUCT', productId: id });
    if (!r?.ok) throw new Error(`Salla did not return the product (${r?.error || 'no response'})`);
    link = storefrontUrl(r.data?.data);
  }
  if (!link) throw new Error('Salla did not return a store link for this product');
  return link;
}

function readStorePage(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  let name = '';
  doc.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
    if (name) return;
    try {
      const d = JSON.parse(s.textContent);
      const list = Array.isArray(d) ? d : (d['@graph'] || [d]);
      const p = list.find(x => x && x['@type'] === 'Product');
      if (p?.name) name = String(p.name);
    } catch (e) {}
  });
  if (!name) name = doc.querySelector('h1')?.textContent || '';
  return {
    name: flat(name),
    title: flat(doc.querySelector('title')?.textContent),
    desc: flat(doc.querySelector('meta[name="description"]')?.getAttribute('content')),
    canonical: doc.querySelector('link[rel="canonical"]')?.getAttribute('href') || '',
  };
}

function compareStorePage(item, page, finalUrl) {
  const checked = [];
  const issues = [];
  if (item.newName) {
    checked.push('name');
    if (normName(page.name) !== normName(item.newName)) issues.push({ what: 'Name', got: page.name });
  }
  if (item.metaTitle) {
    checked.push('meta title');
    const want = flat(item.metaTitle);
    const rest = page.title.startsWith(want) ? page.title.slice(want.length) : null;
    if (rest === null || !(rest === '' || /^ [|\-–] [^|]+$/.test(rest))) issues.push({ what: 'Meta title', got: page.title });
  }
  if (item.metaDesc) {
    checked.push('meta description');
    if (page.desc !== flat(item.metaDesc)) issues.push({ what: 'Meta description', got: page.desc });
  }
  const slug = cleanProductSlug(item.slug);
  if (slug) {
    checked.push('link');
    let path = '';
    try { path = safeDecode(new URL(page.canonical || finalUrl, finalUrl).pathname).toLowerCase(); } catch (e) {}
    if (!path.split('/').includes(slug)) issues.push({ what: 'Link', got: path });
  }
  if (!checked.length) checked.push('page');
  return { checked, issues };
}

async function checkStorePage(item, link) {
  const url = `${link}${link.includes('?') ? '&' : '?'}seopub_check=${Date.now()}`;
  const res = await fetch(url, { cache: 'no-store', credentials: 'omit', redirect: 'follow' });
  if (!res.ok) return { checked: [], issues: [], error: `the page returned HTTP ${res.status}` };
  return compareStorePage(item, readStorePage(await res.text()), res.url || link);
}

function originsFor(links) {
  const set = new Set();
  links.forEach(l => { try { set.add(`${new URL(l).origin}/*`); } catch (e) {} });
  return [...set];
}

const hostsOf = (origins) => origins.map(o => o.replace(/^https?:\/\//, '').replace(/\/\*$/, '')).join(', ');

async function runLiveCheck(job) {
  const btn = $('btn-live-check');
  const targets = liveTargets(job).filter(i => linkOf(job, i));
  setBusy(btn, 'Checking');
  for (let n = 0; n < targets.length; n++) {
    const i = targets[n];
    btn.textContent = `Checking ${n + 1} of ${targets.length}`;
    try { live.results[i] = await checkStorePage(sentItem(job, i), linkOf(job, i)); }
    catch (e) { live.results[i] = { checked: [], issues: [], error: `the page did not load (${e.message})` }; }
    await sleep(300);
  }
  setBusy(btn);
  forgetFailedLookups();
  await saveLive();
  renderDone(job);
}

$('btn-live-check').addEventListener('click', async () => {
  const job = state.job;
  if (!job) return;
  if (live.jobId !== job.id) Object.assign(live, { jobId: job.id, links: {}, results: {} });
  const note = $('live-note');
  const btn = $('btn-live-check');
  const targets = liveTargets(job);
  const unresolved = targets.filter(i => !linkOf(job, i) && !(i in live.links));

  if (!unresolved.length) {
    const origins = originsFor(targets.map(i => linkOf(job, i)).filter(Boolean));
    if (!origins.length) { forgetFailedLookups(); await saveLive(); note.textContent = 'No store links were found, so nothing could be checked.'; return; }
    let granted = false;
    try { granted = await chrome.permissions.request({ origins }); } catch (e) {}
    if (!granted) { note.textContent = `SEOPub needs your OK to open ${hostsOf(origins)} to check the pages.`; return; }
    note.textContent = '';
    return runLiveCheck(job);
  }

  setBusy(btn, 'Finding product pages');
  for (const i of unresolved) {
    try { live.links[i] = await findStoreLink(job, i); }
    catch (e) { live.links[i] = ''; live.results[i] = { checked: [], issues: [], error: e.message }; }
  }
  setBusy(btn);
  const origins = originsFor(targets.map(i => linkOf(job, i)).filter(Boolean));
  if (!origins.length) forgetFailedLookups();
  await saveLive();
  if (!origins.length) { renderDone(job); note.textContent = 'No store links were found, so nothing could be checked.'; return; }
  let granted = false;
  try { granted = await chrome.permissions.contains({ origins }); } catch (e) {}
  if (granted) return runLiveCheck(job);
  renderDone(job);
  btn.textContent = `Allow access to ${hostsOf(origins)}`;
  note.textContent = 'Firefox asks once before SEOPub can open your store pages. Click the button to allow it and start the check.';
});

function renderDone(job) {
  document.body.classList.remove('running');
  if (!job.seen) { job.seen = true; send({ type: 'JOB_SEEN' }); }
  const { ok, failed, notRun } = jobCounts(job);
  const retryable = failed + notRun;

  $('done-ok').textContent = ok;
  $('done-err').textContent = failed;
  $('done-skipped').textContent = job.skipped.length + notRun;
  $('done-title').textContent = notRun ? 'Stopped' : failed ? 'Finished with errors' : 'All done';
  $('screen-done').dataset.outcome = notRun ? 'stopped' : failed ? 'error' : 'ok';
  document.querySelector('.tally .t-err').classList.toggle('has', failed > 0);

  const [platform, mode] = job.key.split(':');
  const notes = [];
  if (mode === 'articles' && ok) notes.push(platform === 'zid'
    ? 'Articles are saved as unpublished in Zid. Review them, then publish from the dashboard.'
    : 'Articles are saved as drafts in Salla. Review them, then publish from the dashboard.');
  if (mode === 'products' && ok) notes.push(`Product changes are live in ${job.store}.`);
  $('done-note').textContent = notes.join(' ');

  const lv = liveFor(job);
  const rows = jobRows(job).sort((a, b) => STATUS_ORDER[a.status] - STATUS_ORDER[b.status]);
  $('done-list').replaceChildren(...rows.map(r => {
    const lr = r.idx >= 0 ? lv.results[r.idx] : null;
    const link = r.idx >= 0 ? linkOf(job, r.idx) : '';
    const liveEl = !lr ? null : lr.error || lr.issues.length
      ? h('div', { class: 'live live-bad', dir: 'auto' },
          h('strong', { text: lr.error ? 'Website check failed' : 'Different on the website' }),
          ...(lr.error
            ? [h('span', { dir: 'auto', text: lr.error })]
            : lr.issues.map(x => h('span', {}, `${x.what}: `, x.got ? h('bdi', { dir: 'auto', text: x.got }) : 'missing'))))
      : h('div', { class: 'live live-ok', dir: 'auto', text: liveText(lr) });
    return h('div', { class: `result ${r.status}` },
      h('span', { class: 'mark', 'aria-label': STATUS_LABEL[r.status], text: STATUS_MARK[r.status] }),
      h('div', {},
        h('div', { class: 'name', dir: 'auto', text: r.name }),
        r.note ? h('div', { class: 'note', dir: 'auto', text: r.note }) : null,
        liveEl),
      link ? h('a', { href: link, target: '_blank', rel: 'noopener', text: 'Open' }) : h('span'),
    );
  }));

  const showLive = canLiveCheck(job);
  $('live-wrap').classList.toggle('hidden', !showLive);
  if (showLive) {
    const checked = liveTargets(job).filter(i => lv.results[i]);
    const good = checked.filter(i => !lv.results[i].error && !lv.results[i].issues.length).length;
    const btn = $('btn-live-check');
    if (!btn.disabled) btn.textContent = checked.length ? 'Check again on website' : 'Check on website';
    $('live-note').textContent = checked.length
      ? `${good} of ${checked.length} match on the website.`
      : 'Opens each updated product on your store and compares what is live with what was sent.';
  }

  const retry = $('btn-retry');
  retry.classList.toggle('hidden', retryable === 0);
  retry.disabled = false;
  retry.textContent = failed && notRun ? `Retry ${retryable} unfinished`
    : failed ? `Retry ${failed} failed` : `Run the ${notRun} left`;
  show('screen-done');
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type !== 'JOB_UPDATE') return;
  state.job = msg.job;
  if (msg.job?.status === 'running') state.watching = true;
  if (state.watching) renderJob(msg.job);
  else renderLastRun();
});

$('btn-retry').addEventListener('click', async () => {
  setBusy($('btn-retry'), 'Starting');
  const res = await send({ type: 'JOB_RETRY' });
  if (!res?.ok) { setBusy($('btn-retry')); $('done-note').textContent = res?.error || 'The retry did not start.'; return; }
  state.watching = true;
  await refreshJob();
});

const REPORT_HEAD = ['Name', 'Status', 'Details', 'Link', 'Website check'];

function reportRows() {
  const job = state.job;
  const lv = liveFor(job);
  return jobRows(job).map(r => {
    const lr = r.idx >= 0 ? lv.results[r.idx] : null;
    return [r.name, STATUS_LABEL[r.status], r.note || '', r.idx >= 0 ? linkOf(job, r.idx) : '', lr ? liveText(lr) : ''];
  });
}

$('btn-copy-report').addEventListener('click', async () => {
  const text = [REPORT_HEAD, ...reportRows()]
    .map(cols => cols.map(c => String(c).replace(/[\t\n]+/g, ' ')).join('\t')).join('\n');
  const btn = $('btn-copy-report');
  try {
    await navigator.clipboard.writeText(text);
    btn.textContent = 'Copied';
  } catch (e) {
    btn.textContent = 'Copy failed';
  }
  setTimeout(() => { btn.textContent = 'Copy report'; }, 1600);
});

$('btn-download-report').addEventListener('click', () => {
  const esc = (c) => `"${String(c).replace(/"/g, '""')}"`;
  const csv = '﻿' + [REPORT_HEAD, ...reportRows()].map(r => r.map(esc).join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const stamp = new Date(state.job.startedAt).toISOString().slice(0, 16).replace(/[T:]/g, '');
  const a = h('a', { href: url, download: `seopub-${state.job.key.replace(':', '-')}-${stamp}.csv` });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
});

// ── Init ──────────────────────────────────────────
async function init() {
  show('screen-setup');
  const stored = await chrome.storage.local.get(['sheetUrl', 'platform', 'mode', 'sallaUi', 'recentSheets', 'mappings', 'liveCheck']);
  if (stored.liveCheck?.jobId) Object.assign(live, stored.liveCheck);
  if (stored.sheetUrl) $('sheet-url').value = stored.sheetUrl;
  if (stored.platform) state.platform = stored.platform;
  if (stored.mode) state.mode = stored.mode;
  if (stored.sallaUi) state.sallaUi = stored.sallaUi;
  if (stored.mappings) state.mappings = stored.mappings;
  renderRecent(stored.recentSheets || (stored.sheetUrl ? [stored.sheetUrl] : []));
  resetTabPicker();
  syncSetup();
  await refreshJob();
}

init();
