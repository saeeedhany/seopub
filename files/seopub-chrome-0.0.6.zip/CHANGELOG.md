# SEOPub changelog

Versions before 0.1.0 are test builds. 0.1.0 is tagged once a build is confirmed stable on real Salla and Zid stores.

## 0.0.6

New

1. SEOPub has an install page, and Firefox now updates it automatically from there. Installing 0.0.6 from the page once is enough; later versions arrive on their own.
2. A Chrome version, installed from the same page in developer mode.
3. SEOPub's own icon shows in the browser's add-ons list.

## 0.0.5

Fixes

1. Check on website compares against the link the product was actually saved with. When Salla rejected a link as taken and SEOPub saved it with a number added, the check used to report the link as different every time. Runs made with 0.0.4 are read correctly too.
2. When finding a product's store page fails, for example because the Salla tab was logged out, "Check again on website" now looks it up again instead of keeping the old failure.

## 0.0.4

New

1. Check on website: after a Salla product update, the results screen has a "Check on website" button. It opens each updated product on the live store and compares the name, meta title, meta description and link with what was sent. Each row shows whether it matches, or what the website shows instead. The result is also added to the copied and downloaded report.
2. Product runs now keep each product's store link and ID, so the "Open" button works and the website check starts right away. For runs made before 0.0.4, SEOPub looks the links up through the Salla dashboard first.
3. Firefox asks once for permission to open your store's domain. SEOPub only asks for the domain it needs.

## 0.0.3

Fixes

1. A saved column choice that points a field at the wrong kind of column (for example meta title on "Meta Title الحالي", or product name on a "new name" column) is no longer reused. SEOPub picks the right column again, so a mapping saved before 0.0.2 cannot keep sending old values to the store.
2. The column screen warns when you pick a current value column for a field that is sent to the store, or a new value column for the product name used to find it.
3. Salla product rows with a meta title over 70 characters are listed under skipped rows on the review screen with the reason, instead of failing in Salla with HTTP 422.

## 0.0.2

Fixes

1. When a sheet has both a current and a new column for the same field (for example "Meta Title الحالي" and "Meta Title الجديد"), column matching now picks the new one for meta title, meta description, slug and description doc, and the current one for the product name. Before, it picked whichever came first, which sent the old values to the store and could fail Salla's 70 character title limit.

## 0.0.1

First build under the SEOPub name and add-on ID (`seopub@extension`), versioned independently from the extension it grew out of.

Publishing

1. Publishing runs in the background. Closing or reopening the sidebar no longer stops a run, and reopening it shows the live progress or the results.
2. The last run and its report are saved, and stay available after the sidebar closes or Firefox restarts.
3. A run cut short by a Firefox restart is reported clearly: the row that was in progress is flagged to check before retrying, and the rest are marked as not run.
4. Product search looks through up to 5 pages of results in Salla and Zid, and still refuses to guess when two products share the exact same name.
5. Salla articles wait for the page to be ready instead of fixed delays, which makes each article faster.

Fixes

1. Bold, italic and underline from Google Docs are kept in articles and product descriptions.
2. Keywords with English letters or digits get correct links, and their cover images match.
3. Retrying a failed Zid article reuses the article Zid already created instead of making a duplicate.
4. Duplicate rows in the sheet are skipped.
5. Zid products named only in English are found.
6. The sheet is always read with row 1 as the header row.
7. Select all only affects the rows visible under the current filter.

Look

1. A warm, light neobrutalist design: oat background, espresso outlines, honey header, sage for Salla and lilac for Zid.
2. Every row on the review screen is shown the way Google displays it, with character counts for the meta title and description.
