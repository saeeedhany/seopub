const JOB_KEY = 'lastJob';
const LOG_LIMIT = 600;
const SEARCH_PAGES = 5;

let job = null;
let keepAliveTimer = null;
let notifyTimer = null;

function publicJob() {
  if (!job) return null;
  const { items, ...rest } = job;
  return { ...rest, items: items.map(({ imageBase64, ...it }) => it) };
}

function saveJob() {
  return chrome.storage.local.set({ [JOB_KEY]: publicJob() }).catch(() => {});
}

function notify() {
  if (notifyTimer) return;
  notifyTimer = setTimeout(() => {
    notifyTimer = null;
    chrome.runtime.sendMessage({ type: 'JOB_UPDATE', job: publicJob() }).catch(() => {});
  }, 150);
}

function log(text, type = 'info') {
  job.log.push({ type, text });
  if (job.log.length > LOG_LIMIT) job.log.splice(0, job.log.length - LOG_LIMIT);
  notify();
}

function startKeepAlive() {
  stopKeepAlive();
  keepAliveTimer = setInterval(() => { chrome.runtime.getPlatformInfo().catch(() => {}); }, 10000);
}

function stopKeepAlive() {
  if (keepAliveTimer) clearInterval(keepAliveTimer);
  keepAliveTimer = null;
}

const detail = (r) => [r?.error, r?.detail].filter(Boolean).join(': ');

// ── إرسال مع إعادة المحاولة لو 429 ──
async function apiSend(msg, platformLabel, retries = 2) {
  for (let a = 0; a <= retries; a++) {
    let res;
    try { res = await handleApi(msg); }
    catch (e) { res = { ok: false, error: e.message }; }
    if (res?.status !== 429) return res;
    log(`${platformLabel} asked to slow down. Waiting 10 seconds.`, 'warn');
    await sleep(10000);
  }
  return { ok: false, error: 'HTTP 429: too many requests in a row' };
}

async function loadDoc(url) {
  const res = await fetchDoc(url);
  if (!res?.ok) throw new Error(`Could not load the doc: ${res?.error}`);
  return res.html;
}

// ── Utilities ─────────────────────────────────────
function waitForTabLoad(tabId, timeoutMs = 20000, targetFragment = null) {
  return new Promise(resolve => {
    const timeout = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(''); }, timeoutMs);
    async function listener(updatedId, info) {
      if (updatedId !== tabId || info.status !== 'complete') return;
      if (!targetFragment) { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(listener); resolve(''); return; }
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab?.url?.includes(targetFragment)) { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(listener); resolve(tab.url); }
      } catch (e) { clearTimeout(timeout); chrome.tabs.onUpdated.removeListener(listener); resolve(''); }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function pollTab(tabId, message, done, timeoutMs, everyMs = 700) {
  const end = Date.now() + timeoutMs;
  let last = null;
  while (Date.now() < end) {
    try { last = await chrome.tabs.sendMessage(tabId, message); if (done(last)) return last; } catch (e) {}
    await sleep(everyMs);
  }
  return last;
}

async function waitForTabUrl(tabId, pattern, timeoutMs) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) return '';
    if (pattern.test(tab.url || '')) return tab.url;
    await sleep(500);
  }
  return '';
}

async function closeTab(tabId) {
  try { await chrome.tabs.remove(tabId); } catch (e) {}
}

async function searchAllPages(fetchPage, namesOf, target) {
  const matches = [];
  const seenIds = new Set();
  let near = [];
  for (let page = 1; page <= SEARCH_PAGES; page++) {
    const { list, more } = await fetchPage(page);
    if (page === 1) near = list.slice(0, 3).map(r => namesOf(r).find(Boolean));
    for (const r of list) {
      if (seenIds.has(r.id)) continue;
      seenIds.add(r.id);
      if (namesOf(r).some(n => normName(n) === target)) matches.push(r);
    }
    if (!more || !list.length) break;
  }
  return { matches, near, searched: seenIds.size };
}

// ── Salla Articles Publishing ─────────────────────
async function processSallaArticle(article) {
  const createUrl = 'https://s.salla.sa/blog/articles/create';
  const isFresh = (r) => !!r?.fresh;
  let tabId = null;
  try {
    const tab = await chrome.tabs.create({ url: createUrl, active: false });
    tabId = tab.id;
    await waitForTabLoad(tabId, 25000, 'articles/create');

    let freshCheck = await pollTab(tabId, { type: 'VERIFY_FRESH_FORM' }, isFresh, 12000);
    for (let retries = 0; !isFresh(freshCheck) && retries < 3; retries++) {
      await chrome.tabs.update(tabId, { url: createUrl });
      await waitForTabLoad(tabId, 25000, 'articles/create');
      freshCheck = await pollTab(tabId, { type: 'VERIFY_FRESH_FORM' }, isFresh, 12000);
    }
    if (!isFresh(freshCheck)) throw new Error(`The add article page did not load${freshCheck?.reason ? ` (${freshCheck.reason})` : ''}`);
    await sleep(1500);

    if (!article.docUrl?.trim()) throw new Error('The doc link is empty');
    const content = await cleanDocAsync(await loadDoc(article.docUrl), false);

    let result;
    try {
      result = await chrome.tabs.sendMessage(tabId, {
        type: 'PUBLISH_ARTICLE',
        article: { keyword: article.keyword, slug: article.slug, metaTitle: article.metaTitle, metaDesc: article.metaDesc, content, imageBase64: article.imageBase64 || null, imageName: article.imageName }
      });
    } catch (e) {
      const tabInfo = await chrome.tabs.get(tabId).catch(() => null);
      result = tabInfo && /\/articles\/\d+\/edit/.test(tabInfo.url || '') ? { ok: true, warning: 'Saved, but the page stopped responding. Check this article.' } : { ok: false, error: e.message };
    }
    if (!result?.ok) throw new Error(result?.error || 'The page did not respond');

    const link = await waitForTabUrl(tabId, /\/articles\/\d+\/edit/, 10000);
    await sleep(1000);
    return { warning: result.warning, link, note: 'Saved as draft.' };
  } finally {
    if (tabId) await closeTab(tabId);
  }
}

// ── Salla Products Publishing (الداشبورد القديم — DOM) ──
async function processSallaProductDom(product) {
  let tabId = null;
  try {
    const searchUrl = `https://s.salla.sa/products?keyword=${encodeURIComponent(product.productName)}`;
    const tab = await chrome.tabs.create({ url: searchUrl, active: false });
    tabId = tab.id;
    await waitForTabLoad(tabId, 30000, 'products');

    const pageCheck = await pollTab(tabId, { type: 'VERIFY_PRODUCTS_PAGE' }, r => r?.ok, 20000, 1000);
    if (!pageCheck?.ok) throw new Error(`The products page did not get ready: ${pageCheck?.reason || 'timed out'}`);
    await sleep(1500);

    let content = '';
    if (product.docUrl) {
      try { content = await cleanDocAsync(await loadDoc(product.docUrl), false); }
      catch (e) { log(`${e.message}. The description stays as it is.`, 'warn'); }
    }

    let result;
    try {
      result = await chrome.tabs.sendMessage(tabId, {
        type: 'PUBLISH_PRODUCT',
        product: { productName: product.productName, newName: product.newName, metaTitle: product.metaTitle, metaDesc: product.metaDesc, slug: product.slug, content }
      });
    } catch (e) { result = { ok: false, error: e.message }; }

    if (!result?.ok) throw new Error(result?.error || 'The page did not respond');
    await sleep(5000);
    return {};
  } finally {
    if (tabId) await closeTab(tabId);
  }
}

// ── Salla Products Publishing (الداشبورد الجديد — API) ──
async function prepareSallaApi() {
  const tabs = await chrome.tabs.query({ url: 'https://s.salla.sa/*' });
  if (!tabs.length) throw new Error('Open the Salla dashboard (s.salla.sa) in a tab and log in, then try again.');
  return {};
}

async function processSallaProductApi(product) {
  // ── 1) البحث بالاسم ──
  const target = normName(product.productName);
  const namesOf = (r) => [r.name];
  const { matches, near } = await searchAllPages(async (page) => {
    const res = await apiSend({ type: 'SALLA_SEARCH_PRODUCTS', query: product.productName, page }, 'Salla');
    if (!res?.ok) throw new Error(`Search failed: ${detail(res)}`);
    const list = Array.isArray(res.data?.data) ? res.data.data : [];
    const pg = res.data?.pagination || {};
    return { list, more: (pg.totalPages || pg.total_pages || 1) > page };
  }, namesOf, target);

  if (matches.length === 0) {
    throw new Error(near.length ? `No exact match. Closest: ${near.join(', ')}` : 'No product with this name in Salla');
  }
  if (matches.length > 1) throw new Error(`${matches.length} products have this exact name, so none were changed`);
  const sp = matches[0];

  // ── 2) الوصف من Google Doc ──
  let content = '';
  if (product.docUrl) {
    content = (await cleanDocAsync(await loadDoc(product.docUrl), false)).replace(/ /g, ' ').trim();
    if (content.length < 100) throw new Error('The doc is empty or too short');
  }

  // ── 3) تجهيز البيانات (اللي ليه قيمة بس) ──
  const data = {};
  const ar = {};
  if (product.newName) { data.name = product.newName; ar.name = product.newName; }
  if (content) { data.description = content; ar.description = content; }
  if (product.metaTitle) { data.metadata_title = product.metaTitle; ar.metadata_title = product.metaTitle; }
  if (product.metaDesc) { data.metadata_description = product.metaDesc; ar.metadata_description = product.metaDesc; }
  const slug = cleanProductSlug(product.slug);
  if (slug) { data.metadata_url = slug; ar.metadata_url = slug; }
  if (Object.keys(ar).length) data.translations = { ar };

  if (!Object.keys(data).length) return { note: 'Nothing needed changing.' };

  // ── 4) PUT ──
  let pRes = await apiSend({ type: 'SALLA_UPDATE_PRODUCT', productId: sp.id, data }, 'Salla');
  let warning = '';
  let sentSlug = slug;

  if (!pRes?.ok && slug && /metadata_url|url|slug/i.test(pRes?.detail || '')) {
    const alt = `${slug}-${Date.now().toString().slice(-4)}`;
    data.metadata_url = alt;
    data.translations.ar.metadata_url = alt;
    log(`Salla rejected the link. Trying ${alt}`, 'warn');
    pRes = await apiSend({ type: 'SALLA_UPDATE_PRODUCT', productId: sp.id, data }, 'Salla');
    if (pRes?.ok) { warning = `The link was taken, so it was saved as ${alt}`; sentSlug = alt; }
  }
  if (!pRes?.ok) throw new Error(`Update failed: ${detail(pRes)}`);
  return { warning, productId: sp.id, slug: sentSlug, link: storefrontUrl(pRes.data?.data) || storefrontUrl(sp) };
}

// ── Zid Articles Publishing ───────────────────────
async function prepareZid() {
  const storeId = await getZidStoreId();
  if (!storeId) throw new Error('Open your store in the Zid dashboard (dashboard.zid.sa) and log in, then try again.');
  log(`Zid store ${storeId}`, 'info');
  return { storeId };
}

async function processZidArticle(article, { storeId }) {
  let tabId = null;
  try {
    if (!article.docUrl) throw new Error('The doc link is empty');
    const content = await cleanDocAsync(await loadDoc(article.docUrl), true);

    let articleId = article.zidArticleId;
    if (articleId) {
      log(`Reusing article ${articleId} from the earlier attempt`, 'info');
    } else {
      const createRes = await handleApi({ type: 'ZID_CREATE_ARTICLE', storeId, data: { title: { ar: article.keyword }, status: 'unpublished' } });
      if (!createRes?.ok) throw new Error(`Could not create the article: ${detail(createRes)}`);
      articleId = createRes.id;
      article.zidArticleId = articleId;
      saveJob();
      log(`Created article ${articleId}`, 'info');
    }

    const cleanContent = content
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
      .replace(/ /g, ' ')
      .trim();

    const patchData = {
      content: { ar: cleanContent },
      snippet: article.snippet ? { ar: article.snippet.slice(0, 160) } : undefined,
      seo: {
        title: { ar: (article.metaTitle || '').slice(0, 70) },
        description: { ar: (article.metaDesc || '').slice(0, 127) }
      },
      slug: article.slug,
    };

    let patchRes = await handleApi({ type: 'ZID_PATCH_ARTICLE', storeId, articleId, data: patchData });
    let warning = '';

    if (!patchRes?.ok && patchRes?.detail?.includes('slug')) {
      const uniqueSlug = article.slug + '-' + Date.now().toString().slice(-4);
      patchData.slug = uniqueSlug;
      log(`The link is taken. Trying ${uniqueSlug}`, 'warn');
      patchRes = await handleApi({ type: 'ZID_PATCH_ARTICLE', storeId, articleId, data: patchData });
      if (patchRes?.ok) warning = `The link was taken, so it was saved as ${uniqueSlug}`;
    }
    if (!patchRes?.ok) throw new Error(`Could not fill in the article: ${detail(patchRes)}`);

    const zidUrl = `https://dashboard.zid.sa/ar-sa/stores/${storeId}/channels/online-store/blog/${articleId}`;
    if (article.imageBase64) {
      const tab = await chrome.tabs.create({ url: zidUrl, active: false });
      tabId = tab.id;
      await waitForTabLoad(tabId, 30000, `/blog/${articleId}`);
      await sleep(8000);

      let imgResult = { ok: false, error: 'No response' };
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          imgResult = await chrome.tabs.sendMessage(tabId, {
            type: 'ZID_UPLOAD_IMAGE',
            imageBase64: article.imageBase64,
            imageName: article.imageName || 'cover.jpg'
          });
          if (imgResult?.ok) break;
        } catch (e) {
          imgResult = { ok: false, error: e.message };
        }
        await sleep(3000);
      }

      if (!imgResult?.ok) warning = [warning, `The cover image did not upload: ${imgResult?.error}`].filter(Boolean).join('. ');
      else log('Cover image uploaded', 'info');
      await sleep(5000);
    }

    return { warning, link: zidUrl, note: 'Saved as unpublished.' };
  } finally {
    if (tabId) await closeTab(tabId);
  }
}

// ── Zid Products Publishing ───────────────────────
async function processZidProduct(product, { storeId }) {
  // ── 1) البحث بالاسم ──
  const target = normName(product.productName);
  const namesOf = (r) => typeof r.name === 'string' ? [r.name] : [r.name?.ar, r.name?.en];
  const { matches, near } = await searchAllPages(async (page) => {
    const res = await apiSend({ type: 'ZID_SEARCH_PRODUCTS', storeId, query: product.productName, page }, 'Zid');
    if (!res?.ok) throw new Error(`Search failed: ${detail(res)}`);
    const list = res.data?.results || [];
    return { list, more: res.data?.next ? true : list.length >= 50 };
  }, namesOf, target);

  if (matches.length === 0) {
    throw new Error(near.length ? `No exact match. Closest: ${near.join(', ')}` : 'No product with this name in Zid');
  }
  if (matches.length > 1) throw new Error(`${matches.length} products have this exact name, so none were changed`);
  const zp = matches[0];

  // ── 2) الوصف من Google Doc ──
  let content = '';
  if (product.docUrl) {
    content = (await cleanDocAsync(await loadDoc(product.docUrl), true))
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
      .replace(/ /g, ' ')
      .trim();
    if (content.length < 100) throw new Error('The doc is empty or too short');
  }

  // ── 3) تجهيز البيانات (الحقول اللي ليها قيمة بس) ──
  const data = {};
  if (product.newName) data.name = { ar: product.newName };
  if (content) data.description = { ar: content };

  if (product.metaTitle || product.metaDesc) {
    data.seo = {
      title: { ar: (product.metaTitle || zp.seo?.title?.ar || '').slice(0, 70) },
      description: { ar: (product.metaDesc || zp.seo?.description?.ar || '').slice(0, 160) },
    };
  }

  const slug = cleanProductSlug(product.slug);
  if (slug && slug !== zp.slug) data.slug = slug;

  if (!Object.keys(data).length) return { note: 'Nothing needed changing.' };

  // ── 4) PATCH ──
  let pRes = await apiSend({ type: 'ZID_PATCH_PRODUCT', storeId, productId: zp.id, data }, 'Zid');
  const warnings = [];

  if (!pRes?.ok && data.slug && /slug/i.test(pRes?.detail || '')) {
    data.slug = `${slug}-${Date.now().toString().slice(-4)}`;
    log(`The link is taken. Trying ${data.slug}`, 'warn');
    pRes = await apiSend({ type: 'ZID_PATCH_PRODUCT', storeId, productId: zp.id, data }, 'Zid');
    if (pRes?.ok) warnings.push(`The link was taken, so it was saved as ${data.slug}`);
  }
  if (!pRes?.ok) throw new Error(`Update failed: ${detail(pRes)}`);

  // ── 5) تحقق سريع ──
  const saved = pRes.data || {};
  if (data.seo && saved.seo?.title?.ar !== data.seo.title.ar) warnings.push('Zid saved a different meta title. Check it');
  if (data.slug && saved.slug && saved.slug !== data.slug) warnings.push(`Zid changed the link to ${saved.slug}`);
  return { warning: warnings.join('. ') };
}

// ── Job runner ────────────────────────────────────
function runnerFor(key, sallaUi) {
  switch (key) {
    case 'salla:articles': return { run: processSallaArticle, gap: 1000, needsImage: true };
    case 'zid:articles': return { prepare: prepareZid, run: processZidArticle, gap: 1500, needsImage: true };
    case 'salla:products': return sallaUi === 'old'
      ? { run: processSallaProductDom, gap: 2000 }
      : { prepare: prepareSallaApi, run: processSallaProductApi, gap: 800 };
    case 'zid:products': return { prepare: prepareZid, run: processZidProduct, gap: 800 };
    default: return null;
  }
}

async function runIndexes(indexes) {
  const runner = runnerFor(job.key, job.sallaUi);
  job.status = 'running';
  job.seen = false;
  job.stopRequested = false;
  job.batchTotal = indexes.length;
  job.batchDone = 0;
  job.batchStarted = Date.now();
  job.finishedAt = null;
  indexes.forEach(i => { job.results[i] = null; });
  startKeepAlive();
  await saveJob();
  notify();

  let ctx = {};
  try {
    if (runner.prepare) ctx = (await runner.prepare()) || {};
  } catch (e) {
    log(e.message, 'err');
    indexes.forEach(i => { job.results[i] = { status: 'error', note: e.message }; });
    return finishJob();
  }

  for (let n = 0; n < indexes.length; n++) {
    const i = indexes[n];
    const item = job.items[i];
    if (job.stopRequested) {
      log('Stopped.', 'warn');
      indexes.slice(n).forEach(k => { job.results[k] = { status: 'stopped', note: 'Not run, stopped before this one' }; });
      break;
    }
    job.current = i;
    await saveJob();
    log(`${n + 1} of ${indexes.length}: ${item.name}`, 'run');
    try {
      if (runner.needsImage && item.hadImage && !item.imageBase64) {
        throw new Error('The cover image is no longer loaded. Start over and add the images again.');
      }
      const r = (await runner.run(item, ctx)) || {};
      if (r.warning) log(r.warning, 'warn');
      log(r.note ? `Done. ${r.note}` : 'Done.', 'ok');
      job.results[i] = { status: r.warning ? 'warn' : 'ok', note: r.warning || r.note || '', link: r.link || '', productId: r.productId || null, slug: r.slug || '' };
    } catch (e) {
      log(`Failed: ${e.message}`, 'err');
      job.results[i] = { status: 'error', note: e.message };
    }
    job.batchDone = n + 1;
    job.current = null;
    await saveJob();
    notify();
    if (n < indexes.length - 1 && !job.stopRequested) await sleep(runner.gap);
  }
  return finishJob();
}

async function finishJob() {
  job.status = 'done';
  job.current = null;
  job.finishedAt = Date.now();
  stopKeepAlive();
  await saveJob();
  notify();
}

async function startJob(spec) {
  if (job?.status === 'running') return { ok: false, error: 'A run is already in progress.' };
  if (!runnerFor(spec.key, spec.sallaUi)) return { ok: false, error: 'Unknown job type.' };
  job = {
    id: Date.now(),
    key: spec.key,
    sallaUi: spec.sallaUi,
    store: spec.store,
    one: spec.one,
    many: spec.many,
    verb: spec.verb,
    items: spec.items.map(it => ({ ...it, hadImage: !!it.imageBase64 })),
    results: spec.items.map(() => null),
    skipped: spec.skipped || [],
    log: [],
    status: 'running',
    stopRequested: false,
    startedAt: Date.now(),
  };
  runIndexes(job.items.map((_, i) => i));
  return { ok: true };
}

function retryJob() {
  if (!job) return { ok: false, error: 'There is no run to retry.' };
  if (job.status === 'running') return { ok: false, error: 'A run is already in progress.' };
  const indexes = job.results.map((r, i) => (r?.status === 'error' || r?.status === 'stopped') ? i : -1).filter(i => i >= 0);
  if (!indexes.length) return { ok: false, error: 'Nothing left to retry.' };
  log(`Retrying ${indexes.length}`, 'run');
  runIndexes(indexes);
  return { ok: true };
}

function handleJobMessage(msg) {
  switch (msg.type) {
    case 'JOB_START': return startJob(msg.spec);
    case 'JOB_STOP':
      if (job?.status === 'running') { job.stopRequested = true; notify(); }
      return { ok: true };
    case 'JOB_RETRY': return retryJob();
    case 'JOB_GET': return { job: publicJob() };
    case 'JOB_SEEN':
      if (job && job.status === 'done' && !job.seen) { job.seen = true; saveJob(); }
      return { ok: true };
    default: return undefined;
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!String(msg?.type).startsWith('JOB_') || msg.type === 'JOB_UPDATE') return;
  ready.then(() => handleJobMessage(msg)).then(sendResponse, (e) => sendResponse({ ok: false, error: e.message }));
  return true;
});

async function restoreJob() {
  const stored = (await chrome.storage.local.get(JOB_KEY))[JOB_KEY];
  if (!stored || job) return;
  job = stored;
  if (job.status === 'running') {
    job.results = job.results.map((r, i) => {
      if (r) return r;
      return i === job.current
        ? { status: 'stopped', note: 'Interrupted while this one was running. Check it in your dashboard before retrying.' }
        : { status: 'stopped', note: 'Not run, Firefox closed or the extension restarted first' };
    });
    job.log.push({ type: 'warn', text: 'The run was interrupted.' });
    job.status = 'done';
    job.seen = false;
    job.current = null;
    job.finishedAt = Date.now();
    await saveJob();
  }
}

const ready = restoreJob().catch(() => {});
