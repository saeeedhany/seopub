importScripts('common.js', 'background.js', 'runner.js');

let creatingOffscreen = null;

async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  creatingOffscreen ||= chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['DOM_PARSER'],
    justification: 'Clean the Google Docs HTML before it is published',
  }).finally(() => { creatingOffscreen = null; });
  await creatingOffscreen;
}

globalThis.cleanDocRemote = async (raw, removeImages) => {
  await ensureOffscreen();
  const res = await chrome.runtime.sendMessage({ type: 'OFFSCREEN_CLEAN_DOC', raw, removeImages });
  if (!res?.ok) throw new Error(`The doc could not be read (${res?.error || 'no response'})`);
  return res.html;
};
