chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== 'OFFSCREEN_CLEAN_DOC') return;
  try { sendResponse({ ok: true, html: cleanDocHtmlInternal(msg.raw, msg.removeImages) }); }
  catch (e) { sendResponse({ ok: false, error: e.message }); }
});
