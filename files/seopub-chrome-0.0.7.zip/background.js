// ===================================================
// SEO Publisher -Ezz — Background Service Worker v1.4
// ===================================================

// ── فتح الـ Side Panel لما تضغط على أيقونة الإكستنشن ──
if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
} else if (globalThis.browser?.sidebarAction) {
  browser.action.onClicked.addListener(() => browser.sidebarAction.toggle());
}

// ── Message handler ───────────────────────────────
function handleApi(msg) {
  const page = Math.max(1, parseInt(msg.page) || 1);
  switch (msg.type) {
    case "FETCH_SHEET": return fetchSheet(msg.url, msg.tabName, msg.gid);
    case "LIST_SHEET_TABS": return listSheetTabs(msg.url);
    case "FETCH_DOC": return fetchDoc(msg.url);
    // ── سلة: منتجات (الداشبورد الجديد — API) ──
    case "SALLA_SEARCH_PRODUCTS":
      return sallaApiCall('GET', `https://api.salla.dev/admin/v2/products?format=light&keyword=${encodeURIComponent(msg.query)}&page=${page}`, null);
    case "SALLA_GET_PRODUCT":
      return sallaApiCall('GET', `https://api.salla.dev/admin/v2/products/${msg.productId}`, null);
    case "SALLA_UPDATE_PRODUCT":
      return sallaApiCall('PUT', `https://api.salla.dev/admin/v2/products/${msg.productId}`, msg.data);
    // ── زد: مقالات ──
    case "ZID_CREATE_ARTICLE":
      return zidApiCall(msg.storeId, 'POST', 'https://hermod.zid.sa/v2/blogs/posts/', msg.data);
    case "ZID_PATCH_ARTICLE":
      return zidApiCall(msg.storeId, 'PATCH', `https://hermod.zid.sa/v2/blogs/posts/${msg.articleId}/`, msg.data);
    // ── زد: منتجات ──
    case "ZID_SEARCH_PRODUCTS":
      return zidApiCall(msg.storeId, 'GET', `https://hermod.zid.sa/v1/products/?page=${page}&page_size=50&q=${encodeURIComponent(msg.query)}`, null);
    case "ZID_PATCH_PRODUCT":
      return zidApiCall(msg.storeId, 'PATCH', `https://hermod.zid.sa/v1/products/${msg.productId}`, msg.data);
    default: return null;
  }
}

const TAB_HANDLERS = {
  UPLOAD_VIA_FILEPOND: (tabId, msg) => uploadViaFilePond(tabId, msg.base64, msg.name, msg.altKeyword),
  FILL_QUILL_CONTENT: (tabId, msg) => fillQuillContent(tabId, msg.html),
  OPEN_PRODUCT_MODAL: (tabId, msg) => openProductModalInMainWorld(tabId, msg.productId),
  FILL_SEO_SHADOW: (tabId, msg) => fillSeoShadowInMainWorld(tabId, msg.fieldId, msg.value),
  FILL_PRODUCT_QUILL: (tabId, msg) => fillProductQuillInMainWorld(tabId, msg.html),
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const api = handleApi(msg);
  if (api) { api.then(sendResponse); return true; }

  if (msg.type === "OPEN_SALLA_TAB") {
    chrome.tabs.create({ url: msg.url, active: false }, (tab) => {
      sendResponse({ tabId: tab.id });
    });
    return true;
  }

  const tabHandler = TAB_HANDLERS[msg.type];
  if (tabHandler) {
    const tabId = sender.tab?.id;
    if (!tabId) { sendResponse({ ok: false, success: false, error: "No target tab" }); return; }
    tabHandler(tabId, msg).then(sendResponse);
    return true;
  }
});

// ── ملء محرر Quill باستخدام الـ API الرسمي بدل innerHTML المباشر ──
async function fillQuillContent(tabId, html) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: (htmlContent) => {
        try {
          if (!window.Quill || typeof window.Quill.find !== "function") {
            return { success: false, error: "The content editor is not available on this page" };
          }
          const editorEl = document.querySelector(".ql-editor");
          if (!editorEl) return { success: false, error: "Could not find the content editor" };

          const container = editorEl.closest(".ql-container") || editorEl.parentElement;
          const quillInstance = window.Quill.find(container) || window.Quill.find(editorEl);
          if (!quillInstance || !quillInstance.clipboard || typeof quillInstance.clipboard.dangerouslyPasteHTML !== "function") {
            return { success: false, error: "Could not attach to the content editor" };
          }

          quillInstance.clipboard.dangerouslyPasteHTML(htmlContent);
          return { success: true };
        } catch (err) {
          return { success: false, error: err.message };
        }
      },
      args: [html],
    });

    const result = results?.[0]?.result;
    return result || { success: false, error: "The page did not respond" };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ── رفع صورة في FilePond من MAIN world ──
async function uploadViaFilePond(tabId, base64, name, altKeyword) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: async (base64Data, fileName, altText) => {
        try {
          if (!window.FilePond || typeof window.FilePond.find !== "function") {
            return { success: false, error: "The image uploader is not available on this page" };
          }
          const inputEl = document.querySelector('input[id^="filepond--browser"]');
          if (!inputEl) return { success: false, error: "Could not find the image upload field" };
          const pondRoot = inputEl.closest(".filepond--root");
          const pond = window.FilePond.find(pondRoot);
          if (!pond || typeof pond.addFile !== "function") {
            return { success: false, error: "Could not attach to the image uploader" };
          }

          const res = await fetch(base64Data);
          const blob = await res.blob();
          const file = new File([blob], fileName || "image.jpg", { type: blob.type });

          const fileItem = await pond.addFile(file);

          let altSet = false;
          try {
            if (fileItem && typeof fileItem.setMetadata === "function") {
              fileItem.setMetadata("alt", altText);
              altSet = true;
            }
          } catch (metaErr) {}

          return { success: true, altSet };
        } catch (err) {
          return { success: false, error: err.message };
        }
      },
      args: [base64, name, altKeyword || ""],
    });

    const result = results?.[0]?.result;
    return result || { success: false, error: "The page did not respond" };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ── List all tabs (sheets) inside a spreadsheet ──
async function listSheetTabs(sheetUrl) {
  try {
    const idMatch = sheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
    if (!idMatch) return { ok: false, error: "This is not a valid Google Sheet link" };
    const sheetId = idMatch[1];

    const pageUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/htmlview`;
    const res = await fetch(pageUrl);
    if (!res.ok) return { ok: false, error: "Could not open the sheet. Share it as 'Anyone with the link' and try again." };

    const html = await res.text();
    const tabs = extractTabsFromHtml(html);

    if (!tabs.length) {
      return { ok: true, tabs: [{ name: "First tab (default)", gid: "0" }], fallback: true };
    }

    return { ok: true, tabs };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

function extractTabsFromHtml(html) {
  const tabs = [];

  const liRegex = /<li[^>]*id=["']sheet-button-(\d+)["'][^>]*>([\s\S]*?)<\/li>/g;
  let m;
  while ((m = liRegex.exec(html)) !== null) {
    const gid = m[1];
    const nameRaw = m[2].replace(/<[^>]+>/g, "").trim();
    if (nameRaw) tabs.push({ name: nameRaw, gid });
  }
  if (tabs.length) return dedupeTabs(tabs);

  const jsonArrayRegex = /"sheetName":"([^"]+)","sheetId":(\d+)/g;
  while ((m = jsonArrayRegex.exec(html)) !== null) {
    tabs.push({ name: m[1], gid: m[2] });
  }

  return dedupeTabs(tabs);
}

function dedupeTabs(tabs) {
  const seen = new Set();
  return tabs.filter((t) => {
    const key = `${t.name}-${t.gid}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// ── Google Sheet → CSV ────────────────────────────
async function fetchSheet(sheetUrl, tabName = null, explicitGid = null) {
  try {
    const idMatch = sheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
    if (!idMatch) return { ok: false, error: "This is not a valid Google Sheet link" };
    const sheetId = idMatch[1];

    let gid = explicitGid;
    if (!gid) {
      const gidMatch = sheetUrl.match(/[#&?]gid=(\d+)/);
      gid = gidMatch ? gidMatch[1] : null;
    }

    let csvUrl = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv&headers=1`;
    if (gid) {
      csvUrl += `&gid=${gid}`;
    } else if (tabName) {
      csvUrl += `&sheet=${encodeURIComponent(tabName)}`;
    }

    const res = await fetch(csvUrl);
    if (!res.ok) return { ok: false, error: "Cannot fetch sheet. Make sure it is shared publicly." };
    const text = await res.text();

    if (text.trim().startsWith("<")) {
      return { ok: false, error: "Could not find that tab. Check the tab name and the sharing settings." };
    }

    return { ok: true, csv: text };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ── Google Doc → HTML ─────────────────────────────
async function fetchDoc(docUrl) {
  try {
    docUrl = docUrl.trim().replace(/[^\x00-\x7F]/g, '').trim();

    let realUrl = docUrl;
    if (docUrl.includes("google.com/url")) {
      try {
        const urlObj = new URL(docUrl);
        const extracted = urlObj.searchParams.get("q");
        if (extracted) realUrl = extracted;
      } catch (e) {}
    }

    const decodedUrl = decodeURIComponent(realUrl);
    const match = decodedUrl.match(/\/document\/d\/([a-zA-Z0-9_-]+)/) || realUrl.match(/\/document\/d\/([a-zA-Z0-9_-]+)/);
    if (!match) return { ok: false, error: `This is not a valid Google Doc link: ${docUrl.slice(0, 80)}` };
    const docId = match[1];

    const exportUrl = `https://docs.google.com/document/d/${docId}/export?format=html`;
    const res = await fetch(exportUrl);
    if (!res.ok) return { ok: false, error: "Cannot fetch doc. Make sure it is shared publicly." };
    const html = await res.text();

    if (!html || html.trim().length < 50) {
      return { ok: false, error: "The document is empty or not shared" };
    }

    return { ok: true, html };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ── فتح modal المنتج من MAIN world (سلة — الداشبورد القديم) ──
async function openProductModalInMainWorld(tabId, productId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: (pid) => {
        try {
          const box = document.getElementById(`product_conent_${pid}`);
          if (!box) return { ok: false, error: `Could not find product ${pid} on the page` };

          const optionsBtn = box.querySelector('#productOptionsBtn, .product-options-btn');
          if (optionsBtn) {
            optionsBtn.click();
            return { ok: true, method: 'productOptionsBtn' };
          }

          const wrapper = box.querySelector('.options-wrapper');
          if (wrapper) {
            wrapper.click();
            return { ok: true, method: 'options-wrapper' };
          }

          const vue = box.__vue__;
          if (vue && typeof vue.openOptionsAndQuantity === 'function') {
            vue.openOptionsAndQuantity();
            return { ok: true, method: 'vue' };
          }

          return { ok: false, error: "Could not find the product details button" };
        } catch (err) {
          return { ok: false, error: err.message };
        }
      },
      args: [productId],
    });

    const result = results?.[0]?.result;
    return result || { ok: false, error: "No response from the page" };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ── ملء حقل SEO في Shadow DOM من MAIN world (سلة — الداشبورد القديم) ──
async function fillSeoShadowInMainWorld(tabId, fieldId, value) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: (fId, val) => {
        try {
          let cleanVal = val;
          try { cleanVal = decodeURIComponent(val); } catch (e) {}

          const el = document.querySelector(fId);
          if (!el) return { ok: false, error: `Could not find the field ${fId}` };

          const litInput = el.shadowRoot?.querySelector('lit-input');
          const realInput = litInput?.shadowRoot?.querySelector('input, textarea');
          if (!realInput) return { ok: false, error: `Could not find the input inside ${fId}` };

          realInput.focus();
          realInput.value = cleanVal;
          realInput.dispatchEvent(new Event('input', { bubbles: true }));
          realInput.dispatchEvent(new Event('change', { bubbles: true }));
          realInput.blur();

          return { ok: true, setValue: realInput.value };
        } catch (err) {
          return { ok: false, error: err.message };
        }
      },
      args: [fieldId, value],
    });

    const result = results?.[0]?.result;
    return result || { ok: false, error: "No response from the page" };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ── ملء Quill المنتج من MAIN world (سلة — الداشبورد القديم) ──
async function fillProductQuillInMainWorld(tabId, html) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: (htmlContent) => {
        try {
          const editorEl = document.querySelector('#editor_description_ar .ql-editor')
                        || document.querySelector('.ql-editor');
          if (!editorEl) return { success: false, error: "Could not find the description editor" };

          try {
            const container = editorEl.closest('.ql-container') || editorEl.parentElement;
            if (window.Quill && typeof window.Quill.find === 'function') {
              const quillInstance = window.Quill.find(container) || window.Quill.find(editorEl);
              if (quillInstance?.clipboard?.dangerouslyPasteHTML) {
                quillInstance.clipboard.dangerouslyPasteHTML(htmlContent);
                return { success: true, method: 'quill-api' };
              }
            }
          } catch (e) {}

          editorEl.focus();
          editorEl.innerHTML = htmlContent;
          editorEl.dispatchEvent(new Event('input', { bubbles: true }));
          editorEl.dispatchEvent(new Event('change', { bubbles: true }));
          return { success: true, method: 'innerHTML' };

        } catch (err) {
          return { success: false, error: err.message };
        }
      },
      args: [html],
    });

    const result = results?.[0]?.result;
    return result || { success: false, error: "No response from the page" };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

// ── Salla Admin API عبر تاب سلة (الداشبورد الجديد) ──
async function sallaApiCall(method, url, data) {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://s.salla.sa/*' });
    if (!tabs.length) return { ok: false, error: 'Open the Salla dashboard (s.salla.sa) in a tab first' };
    const tab = tabs.find(t => t.active) || tabs[0];

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: async (method, url, data) => {
        try {
          // التوكن: من الـ hook أولاً، وبعدين من localStorage
          let auth = window.__sallaAuth || null;
          if (!auth) {
            try {
              const raw = localStorage.getItem('token');
              let t = raw;
              try {
                const j = JSON.parse(raw);
                t = typeof j === 'string' ? j : (j?.token || j?.access_token || j?.value || null);
              } catch (e) {}
              if (t) auth = /^bearer\s/i.test(t) ? t : `Bearer ${t}`;
            } catch (e) {}
          }
          if (!auth) return { ok: false, error: 'Could not find your Salla login. Reload the Salla tab and try again' };

          const headers = {
            'accept': 'application/json',
            'accept-language': 'ar',
            'authorization': auth
          };
          const options = { method, headers };
          if (data) {
            headers['content-type'] = 'application/json';
            options.body = JSON.stringify(data).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
          }

          const res = await fetch(url, options);
          const text = await res.text();
          let json = {};
          try { json = JSON.parse(text); } catch (e) {}

          if (!res.ok || json.success === false) {
            const hint = res.status === 401 ? '. Reload the Salla tab and try again' : '';
            return { ok: false, status: res.status, error: `HTTP ${res.status}${hint}`, detail: text.slice(0, 500) };
          }
          return { ok: true, status: res.status, data: json };
        } catch (e) {
          return { ok: false, error: e.message };
        }
      },
      args: [method, url, data ?? null]
    });

    return results?.[0]?.result || { ok: false, error: 'No response from the page' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// ── Zid API عبر تاب زد (عشان الكوكيز والتوكن يتبعتوا) ──
async function zidApiCall(storeId, method, url, data) {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://dashboard.zid.sa/*' });
    if (!tabs.length) return { ok: false, error: 'Open dashboard.zid.sa first' };
    const tab = tabs.find(t => t.url?.includes(`/stores/${storeId}`)) || tabs[0];

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: async (storeId, method, url, data) => {
        try {
          const headers = {
            'store-id': String(storeId),
            'role': 'Manager',
            'accept': 'application/json',
            'accept-language': 'ar'
          };
          const token = window.__zidMgrToken;
          if (token) headers['x-manager-token'] = token;

          const options = { method, credentials: 'include', headers };
          if (data) {
            headers['content-type'] = 'application/json';
            const safeData = JSON.parse(
              JSON.stringify(data).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
            );
            options.body = JSON.stringify(safeData);
          }

          const res = await fetch(url, options);
          const text = await res.text();
          let json = {};
          try { json = JSON.parse(text); } catch (e) {}

          if (!res.ok) {
            const hint = (res.status === 401 || res.status === 403) && !token
              ? '. Reload the Zid tab and try again' : '';
            return { ok: false, status: res.status, error: `HTTP ${res.status}${hint}`, detail: text.slice(0, 400) };
          }
          return { ok: true, status: res.status, id: json.id, data: json };
        } catch (e) {
          return { ok: false, error: e.message };
        }
      },
      args: [storeId, method, url, data ?? null]
    });

    return results?.[0]?.result || { ok: false, error: 'No response from the page' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}