function toSlug(text) {
  return text.trim()
    .replace(/[؟،؛:!.""'()\[\]{}«»#@%^&*+=~`|\\/<>]/g, '')
    .replace(/[ً-ٰٟ]/g, '')
    .replace(/\s+/g, '-')
    .replace(/[^؀-ۿݐ-ݿ\w-]/g, '')
    .toLowerCase()
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

// مطابقة الأسماء (تجاهل المسافات الزيادة)
function normName(s) {
  return (s || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
}

// صف فيه أي بيانات تتحدّث
function productHasWork(p) {
  return !!(p.metaTitle || p.metaDesc || p.slug || p.docUrl || p.newName);
}

// تنظيف الـ slug (يقبل رابط كامل أو نص)
function cleanProductSlug(s) {
  if (!s) return '';
  let v = s.trim();
  try { v = decodeURIComponent(v); } catch (e) {}
  v = v.replace(/^https?:\/\/[^/]+\/products\//, '')
       .replace(/[?#].*$/, '')
       .replace(/\/+$/, '')
       .replace(/\s+/g, '-')
       .replace(/-+/g, '-')
       .replace(/^-|-$/g, '');
  return v.toLowerCase();
}

function storefrontUrl(p) {
  const u = p?.urls?.customer || p?.url || '';
  return /^https?:\/\//i.test(u) ? u : '';
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function getZidStoreId() {
  const tabs = await chrome.tabs.query({ url: 'https://dashboard.zid.sa/*' });
  for (const tab of tabs) {
    const match = tab.url?.match(/\/stores\/(\d+)/);
    if (match) return match[1];
  }
  return null;
}

// ── Doc HTML Cleaner ──────────────────────────────
function cleanDocHtml(raw) {
  return cleanDocHtmlInternal(raw, false);
}

function cleanDocHtmlForZid(raw) {
  return cleanDocHtmlInternal(raw, true);
}

async function cleanDocAsync(raw, removeImages) {
  if (typeof DOMParser === 'undefined') return globalThis.cleanDocRemote(raw, removeImages);
  return cleanDocHtmlInternal(raw, removeImages);
}

function docClassFormats(doc) {
  const fmt = {};
  doc.querySelectorAll('style').forEach(st => {
    const re = /\.([\w-]+)\s*\{([^}]*)\}/g;
    let m;
    while ((m = re.exec(st.textContent))) {
      const f = fmt[m[1]] || (fmt[m[1]] = {});
      if (/font-weight\s*:\s*(bold|[6-9]00)/i.test(m[2])) f.b = true;
      if (/font-style\s*:\s*italic/i.test(m[2])) f.i = true;
      if (/text-decoration[^;]*underline/i.test(m[2])) f.u = true;
    }
  });
  return fmt;
}

function keepInlineFormatting(doc, body, fmt) {
  body.querySelectorAll('span').forEach(span => {
    const f = { b: false, i: false, u: false };
    span.classList.forEach(c => { const x = fmt[c]; if (x) { f.b ||= !!x.b; f.i ||= !!x.i; f.u ||= !!x.u; } });
    const st = span.getAttribute('style') || '';
    if (/font-weight\s*:\s*(bold|[6-9]00)/i.test(st)) f.b = true;
    if (/font-style\s*:\s*italic/i.test(st)) f.i = true;
    if (/text-decoration[^;]*underline/i.test(st)) f.u = true;
    if (span.closest('a')) f.u = false;
    if (span.closest('h1, h2, h3, h4, h5, h6')) f.b = false;
    if (!span.textContent.trim()) return;
    [['b', 'strong'], ['i', 'em'], ['u', 'u']].forEach(([k, tag]) => {
      if (!f[k]) return;
      const el = doc.createElement(tag);
      el.append(...span.childNodes);
      span.append(el);
    });
  });
}

function cleanDocHtmlInternal(raw, removeImages) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(raw, 'text/html');
  const body = doc.body;
  if (!body) return '';
  keepInlineFormatting(doc, body, docClassFormats(doc));
  body.querySelectorAll('script, style, head, meta, link, noscript').forEach(el => el.remove());
  if (removeImages) body.querySelectorAll('img, figure, picture').forEach(el => el.remove());
  body.querySelectorAll('a[href]').forEach(a => {
    const href = a.getAttribute('href');
    if (href && href.includes('google.com/url')) {
      try {
        const realUrl = new URL(href).searchParams.get('q');
        if (realUrl) a.setAttribute('href', realUrl);
      } catch (e) {}
    }
  });
  body.querySelectorAll('[style]').forEach(el => {
    if (el.tagName === 'IMG') {
      const style = el.getAttribute('style') || '';
      const width = style.match(/width\s*:\s*([^;]+)/)?.[1]?.trim();
      const height = style.match(/height\s*:\s*([^;]+)/)?.[1]?.trim();
      el.removeAttribute('style');
      if (width) el.setAttribute('width', width.replace('px', ''));
      if (height) el.setAttribute('height', height.replace('px', ''));
    } else { el.removeAttribute('style'); }
  });
  body.querySelectorAll('a > span > img, a > span > span > img').forEach(img => {
    const a = img.closest('a');
    if (!a) return;
    a.replaceChildren(img);
  });
  body.querySelectorAll('span').forEach(span => span.replaceWith(...span.childNodes));
  const html = body.innerHTML.trim();
  return removeImages && html.length > 900000 ? html.slice(0, 900000) : html;
}
