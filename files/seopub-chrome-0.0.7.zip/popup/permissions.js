(() => {
  const origins = chrome.runtime.getManifest().host_permissions || [];

  const refresh = async () => {
    const banner = document.getElementById('perm-banner');
    if (!banner || !chrome.permissions) return;
    let granted = true;
    try { granted = await chrome.permissions.contains({ origins }); } catch (e) {}
    banner.classList.toggle('hidden', granted);
  };

  document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('btn-grant-perms');
    if (btn) {
      btn.addEventListener('click', () => {
        chrome.permissions.request({ origins }).then(refresh, refresh);
      });
    }
    refresh();
  });

  if (chrome.permissions?.onAdded) chrome.permissions.onAdded.addListener(refresh);
  if (chrome.permissions?.onRemoved) chrome.permissions.onRemoved.addListener(refresh);
})();
