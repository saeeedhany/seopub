// ===================================================
// Salla SEO Publisher — Field Inspector (أداة مساعدة)
// ===================================================
//
// طريقة الاستخدام:
// 1. افتح صفحة "إضافة مقال" في سلة
// 2. اضغط F12 لفتح أدوات المطوّر
// 3. روح لتبويب "Console"
// 4. افتح هذا الملف، انسخ كل المحتوى
// 5. لصقه في الـ Console واضغط Enter
// 6. هتظهر قائمة منظمة لكل الحقول — انسخها وابعتها
//
// ملحوظة: هذا الكود لا يغيّر أي شيء في الصفحة، فقط يقرأ ويعرض.

(function inspectSallaPage() {
  console.log("%c🔍 جاري فحص الصفحة...", "color: #5b21b6; font-size: 14px; font-weight: bold;");

  const results = {
    inputs: [],
    textareas: [],
    buttons: [],
    contentEditables: [],
    iframes: [],
    fileInputs: [],
  };

  // ── كل حقول input ──────────────────────────────
  document.querySelectorAll("input").forEach((el, i) => {
    if (el.type === "file") {
      results.fileInputs.push(describeElement(el, i));
    } else if (el.type !== "hidden") {
      results.inputs.push(describeElement(el, i));
    }
  });

  // ── كل textarea ────────────────────────────────
  document.querySelectorAll("textarea").forEach((el, i) => {
    results.textareas.push(describeElement(el, i));
  });

  // ── كل button ──────────────────────────────────
  document.querySelectorAll("button").forEach((el, i) => {
    const text = el.textContent.trim();
    if (text) {
      results.buttons.push({
        index: i,
        text: text,
        selector: buildSelector(el),
        classes: el.className || "(none)",
      });
    }
  });

  // ── محررات النصوص (rich text editors) ──────────
  document.querySelectorAll('[contenteditable="true"]').forEach((el, i) => {
    results.contentEditables.push({
      index: i,
      selector: buildSelector(el),
      classes: el.className || "(none)",
      placeholder: el.getAttribute("data-placeholder") || el.getAttribute("placeholder") || "(none)",
    });
  });

  // ── iframes (ممكن يكون فيها محرر TinyMCE) ───────
  document.querySelectorAll("iframe").forEach((el, i) => {
    results.iframes.push({
      index: i,
      selector: buildSelector(el),
      classes: el.className || "(none)",
      id: el.id || "(none)",
    });
  });

  // ── طباعة النتائج بشكل منظم ─────────────────────
  printSection("📝 حقول الإدخال (Inputs)", results.inputs);
  printSection("📄 حقول النص الطويل (Textareas)", results.textareas);
  printSection("✏️ محررات النصوص (Rich Text)", results.contentEditables);
  printSection("🖼️ نوافذ iframe", results.iframes);
  printSection("📷 رفع ملفات", results.fileInputs);
  printButtonSection("🔘 الأزرار (Buttons)", results.buttons);

  console.log(
    "%c\n✅ انتهى الفحص. انسخ كل ما ظهر في الأعلى وابعته.",
    "color: #059669; font-size: 13px; font-weight: bold;"
  );

  // ── دوال مساعدة ────────────────────────────────
  function describeElement(el, i) {
    return {
      index: i,
      tag: el.tagName.toLowerCase(),
      type: el.type || "(none)",
      name: el.name || "(none)",
      id: el.id || "(none)",
      placeholder: el.placeholder || "(none)",
      classes: el.className || "(none)",
      selector: buildSelector(el),
      nearbyLabel: findNearbyLabel(el),
    };
  }

  function buildSelector(el) {
    if (el.id) return `#${el.id}`;
    if (el.name) return `${el.tagName.toLowerCase()}[name="${el.name}"]`;
    if (el.className) {
      const classes = el.className.trim().split(/\s+/).filter(Boolean);
      // استخدم كل الكلاسات مجمّعة عشان نضمن تحديد دقيق (الكلاس الأول وحده غالباً مشترك بين عناصر تانية)
      if (classes.length) return `${el.tagName.toLowerCase()}.${classes.join(".")}`;
    }
    return el.tagName.toLowerCase();
  }

  function findNearbyLabel(el) {
    // محاولة 1: label مرتبط مباشرة
    if (el.id) {
      const label = document.querySelector(`label[for="${el.id}"]`);
      if (label) return label.textContent.trim();
    }
    // محاولة 2: label أب قريب
    let parent = el.closest("div, td, li");
    if (parent) {
      const label = parent.querySelector("label");
      if (label) return label.textContent.trim();
    }
    // محاولة 3: العنصر السابق مباشرة
    let prev = el.previousElementSibling;
    if (prev && prev.textContent.trim().length < 50) {
      return prev.textContent.trim();
    }
    return "(غير معروف)";
  }

  function printSection(title, items) {
    if (!items.length) {
      console.log(`%c${title}: لا يوجد`, "color: #9ca3af;");
      return;
    }
    console.log(`%c${title} (${items.length})`, "color: #5b21b6; font-weight: bold; font-size: 13px;");
    items.forEach((item) => {
      console.log(
        `  [${item.index}] selector: ${item.selector}\n` +
        `      name="${item.name || "-"}" id="${item.id || "-"}" placeholder="${item.placeholder || "-"}"\n` +
        `      label/نص قريب: "${item.nearbyLabel || "-"}"\n` +
        `      classes: ${item.classes}`
      );
    });
  }

  function printButtonSection(title, items) {
    if (!items.length) {
      console.log(`%c${title}: لا يوجد`, "color: #9ca3af;");
      return;
    }
    console.log(`%c${title} (${items.length})`, "color: #5b21b6; font-weight: bold; font-size: 13px;");
    items.forEach((item) => {
      console.log(`  [${item.index}] نص الزر: "${item.text}"  |  selector: ${item.selector}  |  classes: ${item.classes}`);
    });
  }
})();
