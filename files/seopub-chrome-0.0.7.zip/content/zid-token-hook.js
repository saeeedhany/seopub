// ===================================================
// Zid Token Hook — يشتغل في MAIN world على dashboard.zid.sa
// بيلقط x-manager-token من ريكوستات الداشبورد نفسه
// ويحفظه في ذاكرة الصفحة فقط (مش بيتخزن في أي مكان)
// ===================================================
(() => {
  if (window.__zidHookInstalled) return;
  window.__zidHookInstalled = true;

  const grab = (h) => {
    try {
      if (!h) return;
      let v = null;
      if (h instanceof Headers) v = h.get('x-manager-token');
      else if (Array.isArray(h)) v = (h.find(([k]) => String(k).toLowerCase() === 'x-manager-token') || [])[1];
      else v = h['x-manager-token'] || h['X-Manager-Token'];
      if (v) window.__zidMgrToken = v;
    } catch (e) {}
  };

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    try {
      if (input instanceof Request) grab(input.headers);
      if (init) grab(init.headers);
    } catch (e) {}
    return origFetch.apply(this, arguments);
  };

  const origSet = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    if (String(k).toLowerCase() === 'x-manager-token' && v) window.__zidMgrToken = v;
    return origSet.apply(this, arguments);
  };
})();