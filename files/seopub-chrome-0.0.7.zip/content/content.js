// ===================================================
// Salla SEO Publisher — Content Script v1.1
// Runs inside Salla dashboard pages
// ===================================================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "PUBLISH_ARTICLE") {
    publishArticle(msg.article)
      .then((result) => sendResponse(result))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.type === "PUBLISH_PRODUCT") {
    publishProduct(msg.product)
      .then((result) => sendResponse(result))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.type === "GET_CURRENT_URL") {
    sendResponse({ url: window.location.href });
    return true;
  }

  if (msg.type === "VERIFY_FRESH_FORM") {
    sendResponse(verifyFreshForm());
    return true;
  }

  if (msg.type === "VERIFY_PRODUCTS_PAGE") {
    sendResponse(verifyProductsPage());
    return true;
  }

  if (msg.type === "FIND_PRODUCT_IN_DOM") {
    findProductByName(msg.productName)
      .then((id) => sendResponse({ ok: !!id, productId: id }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.type === "ZID_UPLOAD_IMAGE") {
    zidUploadImage(msg.imageBase64, msg.imageName)
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});

// =====================================================
// ── ARTICLES (existing logic - unchanged) ──
// =====================================================

function verifyFreshForm() {
  const titleEl = document.querySelector('input[name="name"]');
  const isEditUrl = /\/articles\/\d+\/edit|\/articles\/edit\/\d+/.test(window.location.href);
  const titleHasValue = titleEl && titleEl.value && titleEl.value.trim().length > 0;

  if (isEditUrl) return { fresh: false, reason: "This page edits an existing article" };
  if (!titleEl) return { fresh: false, reason: "Could not find the title field" };
  if (titleHasValue) return { fresh: false, reason: `The title field already has text` };

  const metaDescEl = document.querySelector('textarea[name="metadata_description"]');
  const contentEditorEl = document.querySelector("div.ql-editor");

  if (!metaDescEl) return { fresh: false, reason: "The meta description field has not loaded yet" };
  if (!contentEditorEl) return { fresh: false, reason: "The content editor has not loaded yet" };

  return { fresh: true };
}

async function publishArticle(article) {
  const { keyword, slug, metaTitle, metaDesc, content, imageBase64, imageName } = article;

  const titleOk = await fillField(ARTICLE_SELECTORS.title, keyword);
  if (!titleOk) return { ok: false, error: "Could not fill the title. Make sure the add article page is open" };
  await sleep(600);

  await fillField(ARTICLE_SELECTORS.promotionTitle, keyword);
  await sleep(600);

  const MIN_CONTENT_CHARS = 100;
  if (!content || content.trim().length < MIN_CONTENT_CHARS) {
    return { ok: false, error: `The content is empty or too short. Check the Google Doc link` };
  }

  const contentSize = (content || "").length;
  const sizeBasedWait = Math.min(Math.max(3000, Math.round(contentSize / 10000) * 1000), 15000);

  await fillContent(content || `<h1>${keyword}</h1>`);
  await sleep(sizeBasedWait);

  const contentVerified = await verifyContentLanded(content);
  if (!contentVerified) {
    await sleep(sizeBasedWait);
    await fillContent(content || `<h1>${keyword}</h1>`);
    await sleep(sizeBasedWait);
    const retry = await verifyContentLanded(content);
    if (!retry) return { ok: false, error: "Could not confirm the content reached the editor" };
  }

  await fillSeoFields(metaTitle, metaDesc, slug);
  await sleep(600);

  let imageUploaded = false;
  if (imageBase64) {
    imageUploaded = await uploadFeaturedImage(imageBase64, imageName, keyword);
    await sleep(1500);
  }

  const saved = await clickSaveDraft();
  if (!saved) return { ok: false, error: "Could not save the draft" };

  if (imageBase64 && !imageUploaded) {
    return { ok: true, warning: "Article saved, but the cover image did not upload" };
  }

  return { ok: true };
}

// =====================================================
// ── PRODUCTS (new logic) ──
// =====================================================

function verifyProductsPage() {
  const isProductsUrl = /\/products/.test(window.location.href);
  const searchBox = document.getElementById('searchbox');
  if (!isProductsUrl) return { ok: false, reason: "This is not the products page" };
  if (!searchBox) return { ok: false, reason: "Could not find the search box" };
  return { ok: true };
}

async function publishProduct(product) {
  const { productName, newName, metaTitle, metaDesc, slug, content } = product;

  // ── الخطوة 1: البحث عن المنتج في الـ DOM ──
  const productId = await findProductByName(productName);
  if (!productId) {
    return { ok: false, error: `Product not found: "${productName}". The name must match exactly` };
  }

  // ── الخطوة 2: فتح الـ modal عبر MAIN world ──
  // content script في isolated world لا يستطيع الوصول لـ Vue instance مباشرة
  // نطلب من background.js تنفيذ الكود في MAIN world
  let modalOpened = false;
  for (let attempt = 0; attempt < 5; attempt++) {
    const res = await openProductModalViaBackground(productId);
    if (res?.ok) {
      // انتظر تأكيد فتح الـ modal
      await sleep(2500);
      const modal = document.getElementById('modal_product_options');
      if (modal?.classList.contains('in')) {
        modalOpened = true;
        break;
      }
    }
    await sleep(2000);
  }

  if (!modalOpened) {
    return { ok: false, error: `Could not open product ${productId}` };
  }

  // ── الخطوة 3: انتظار تحميل الـ Lit components ──
  await sleep(5000);
  const modalReady = await waitForProductModal(20000);
  if (!modalReady) {
    return { ok: false, error: "The SEO fields did not load" };
  }

  // ── الخطوة 4: ملء اسم المنتج (لو في اسم جديد) ──
  if (newName && newName.trim()) {
    const nameInput = document.getElementById(`${productId}_ar`);
    if (nameInput) {
      nameInput.focus();
      nameInput.value = newName.trim();
      nameInput.dispatchEvent(new Event("input", { bubbles: true }));
      nameInput.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(400);
    }
  }

  // ── الخطوة 5: ملء الوصف (Quill) ──
  if (content && content.trim().length > 100) {
    const filled = await fillProductContent(content);
    if (!filled) {
      return { ok: false, error: "Could not fill the description" };
    }
    await sleep(2000);
  }

  // ── الخطوة 6: ملء حقول SEO عبر MAIN world ──
  await sleep(500);
  await fillSeoFieldViaBackground('#bulk-seo-field-title', metaTitle);
  await sleep(400);
  await fillSeoFieldViaBackground('#bulk-seo-field-custom_url', slug);
  await sleep(400);
  await fillSeoFieldViaBackground('#bulk-seo-field-description', metaDesc);
  await sleep(500);

  // ── الخطوة 7: حفظ ──
  const saved = await clickSaveProduct();
  if (!saved) return { ok: false, error: "Could not find the save button" };

  return { ok: true };
}

// ── فتح modal المنتج عبر background (MAIN world) ──
function openProductModalViaBackground(productId) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "OPEN_PRODUCT_MODAL", productId },
      (response) => {
        if (chrome.runtime.lastError) { resolve({ ok: false }); return; }
        resolve(response);
      }
    );
  });
}

// ── ملء حقل SEO عبر background (MAIN world) ──
function fillSeoFieldViaBackground(fieldId, value) {
  if (!value || !value.trim()) return Promise.resolve({ ok: false });
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "FILL_SEO_SHADOW", fieldId, value: value.trim() },
      (response) => {
        if (chrome.runtime.lastError) { resolve({ ok: false }); return; }
        resolve(response);
      }
    );
  });
}

// ── البحث عن المنتج في الـ DOM بعد تحميل الصفحة ──
// الصفحة بتتفتح على /products?keyword=... — Vue محتاج وقت يحمّل المنتجات
async function findProductByName(productName, maxWait = 15000) {
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    const allProducts = document.querySelectorAll('[id^="product_conent_"]');

    // exact match
    for (const p of allProducts) {
      const nameInput = p.querySelector('input[name="ar[name]"]');
      if (nameInput?.value?.trim() === productName.trim()) {
        return p.id.replace('product_conent_', '');
      }
    }

    // partial match — لو الاسم في الشيت مختلف قليلاً
    if (allProducts.length > 0) {
      for (const p of allProducts) {
        const nameInput = p.querySelector('input[name="ar[name]"]');
        const val = nameInput?.value?.trim() || '';
        // لو 70% من الحروف متطابقة
        if (val && val.length > 5 && productName.includes(val.slice(0, Math.floor(val.length * 0.7)))) {
          return p.id.replace('product_conent_', '');
        }
      }
    }

    await sleep(1000);
  }

  return null;
}

// ── فتح الـ modal بتاع المنتج مع retry ──
async function openProductModal(productId, maxRetries = 5) {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const box = document.getElementById(`product_conent_${productId}`);
    if (!box) { await sleep(1500); continue; }

    const vue = box.__vue__;
    if (!vue || typeof vue.openOptionsAndQuantity !== 'function') {
      await sleep(1500); continue;
    }

    try {
      vue.openOptionsAndQuantity();

      // تحقق إن الـ modal اتفتح فعلاً
      await sleep(2000);
      const modal = document.getElementById('modal_product_options');
      if (modal?.classList.contains('in')) return true;

      // لو مفتحش — انتظر وحاول تاني
      await sleep(1500);
    } catch (e) {
      await sleep(1500);
    }
  }
  return false;
}

// ── انتظار تحميل حقول SEO بعد الضغط على بيانات المنتج ──
// سلة بتوسّع المنتج inline (مش modal دايماً) — نتحقق من وجود bulk-seo-field
async function waitForProductModal(maxWait = 15000) {
  const start = Date.now();
  while (Date.now() - start < maxWait) {
    // سواء كان modal أو inline — المهم إن bulk-seo-field-title موجود ومحمّل
    const titleField = document.querySelector('#bulk-seo-field-title');
    if (titleField) {
      const litInput = titleField.shadowRoot?.querySelector('lit-input');
      const realInput = litInput?.shadowRoot?.querySelector('input, textarea');
      if (realInput) return true;
    }
    await sleep(500);
  }
  return false;
}

// ── ملء حقل SEO في Shadow DOM ──
async function fillSeoShadowField(fieldSelector, value) {
  if (!value || !value.trim()) return false;

  try {
    const el = document.querySelector(fieldSelector);
    if (!el) return false;

    const litInput = el.shadowRoot?.querySelector('lit-input');
    const realInput = litInput?.shadowRoot?.querySelector('input, textarea');
    if (!realInput) return false;

    // scroll للحقل عشان يبقى في الـ viewport (نفس trick المقالات)
    realInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await sleep(300);

    realInput.focus();
    realInput.value = value.trim();
    realInput.dispatchEvent(new Event('input', { bubbles: true }));
    realInput.dispatchEvent(new Event('change', { bubbles: true }));
    realInput.blur();

    // تحقق وأعد لو محتاج
    await sleep(200);
    if (realInput.value !== value.trim()) {
      realInput.focus();
      realInput.value = value.trim();
      realInput.dispatchEvent(new Event('input', { bubbles: true }));
      realInput.dispatchEvent(new Event('change', { bubbles: true }));
      realInput.blur();
    }

    return true;
  } catch (e) {
    return false;
  }
}

// ── ملء الوصف في محرر Quill بتاع المنتج ──
async function fillProductContent(html) {
  // نستخدم background MAIN world عشان نوصل للـ Quill API
  const filled = await fillProductContentViaBackground(html);
  if (filled) return true;

  // fallback مباشر من content script
  const quillEditor = document.querySelector('#editor_description_ar .ql-editor, .ql-editor');
  if (quillEditor) {
    quillEditor.focus();
    quillEditor.innerHTML = html;
    quillEditor.dispatchEvent(new Event('input', { bubbles: true }));
    quillEditor.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  return false;
}

// ── ملء Quill المنتج عبر background MAIN world ──
function fillProductContentViaBackground(html) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "FILL_PRODUCT_QUILL", html },
      (response) => {
        if (chrome.runtime.lastError) { resolve(false); return; }
        resolve(!!response?.success);
      }
    );
  });
}

// ── حفظ المنتج ──
async function clickSaveProduct() {
  // زرار الحفظ في الـ modal
  const modalSave = document.getElementById('save_product_options');
  if (modalSave) {
    modalSave.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await sleep(400);
    modalSave.click();
    return true;
  }

  // زرار الحفظ في الـ inline form
  const inlineSave = document.querySelector(
    '.btn-save, button[class*="btn-save"], #saveProductBtn, button[id*="save"]'
  );
  if (inlineSave) {
    inlineSave.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await sleep(400);
    inlineSave.click();
    return true;
  }

  // fallback: دور على زرار "حفظ بيانات المنتج" بالنص
  const allBtns = document.querySelectorAll('button');
  for (const btn of allBtns) {
    if (btn.textContent?.includes('حفظ بيانات المنتج') || btn.textContent?.includes('حفظ')) {
      btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(400);
      btn.click();
      return true;
    }
  }

  return false;
}

// =====================================================
// ── SHARED HELPERS ──
// =====================================================

const ARTICLE_SELECTORS = {
  title: ['input[name="name"]'],
  promotionTitle: ['input[name="promotion_title"]'],
  content: ['div.ql-editor'],
  metaTitle: ['input[name="metadata_title"]'],
  metaDesc: ['textarea[name="metadata_description"]'],
  slug: ['input[name="custom_url"]'],
  saveDraft: ['#savePost'],
};

function findElement(selectorList) {
  for (const sel of selectorList) {
    try {
      const el = document.querySelector(sel);
      if (el) return el;
    } catch (e) {}
  }
  return null;
}

async function fillField(selectorList, value) {
  const el = findElement(selectorList);
  if (!el) return false;
  el.focus();
  el.value = value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  return true;
}

async function fillContent(html) {
  const filledViaApi = await fillContentViaPageContext(html);
  if (filledViaApi) return true;

  const quill = document.querySelector(".ql-editor");
  if (quill) {
    quill.focus();
    quill.innerHTML = html;
    quill.dispatchEvent(new Event("input", { bubbles: true }));
    return true;
  }
  return false;
}

async function fillSeoFields(metaTitle, metaDesc, slug) {
  const scrollAndFill = async (selectorList, value) => {
    if (!value) return;
    const el = findElement(selectorList);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    await sleep(600);
    el.focus();
    el.value = value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.blur();
    await sleep(300);
    if (el.value !== value) {
      el.focus();
      el.value = value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      el.blur();
    }
  };

  await scrollAndFill(ARTICLE_SELECTORS.metaTitle, metaTitle);
  await sleep(200);
  await scrollAndFill(ARTICLE_SELECTORS.metaDesc, metaDesc);
  await sleep(200);
  await scrollAndFill(ARTICLE_SELECTORS.slug, slug);
  window.scrollTo({ top: 0, behavior: "smooth" });
  await sleep(400);
}

async function uploadFeaturedImage(base64, name, altKeyword) {
  try {
    const uploaded = await uploadViaPageContext(base64, name, altKeyword);
    if (uploaded) { await sleep(1500); return true; }
  } catch (e) {}

  const res = await fetch(base64);
  const blob = await res.blob();
  const file = new File([blob], name || "image.jpg", { type: blob.type });
  const dropZone = findFilePondDropZone();
  if (!dropZone) return false;

  const dt = new DataTransfer();
  dt.items.add(file);
  const dropEvent = new DragEvent("drop", { bubbles: true, cancelable: true, dataTransfer: dt });
  Object.defineProperty(dropEvent, "dataTransfer", { value: dt });
  dropZone.dispatchEvent(new DragEvent("dragenter", { bubbles: true, cancelable: true, dataTransfer: dt }));
  dropZone.dispatchEvent(dropEvent);
  await sleep(2500);
  return !!document.querySelector(".filepond--image-preview, .filepond--file-action-button");
}

function uploadViaPageContext(base64, name, altKeyword) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "UPLOAD_VIA_FILEPOND", base64, name, altKeyword }, (response) => {
      if (chrome.runtime.lastError) { resolve(false); return; }
      resolve(!!response?.success);
    });
  });
}

function fillContentViaPageContext(html) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "FILL_QUILL_CONTENT", html }, (response) => {
      if (chrome.runtime.lastError) { resolve(false); return; }
      resolve(!!response?.success);
    });
  });
}

function verifyContentLanded(expectedHtml) {
  return new Promise((resolve) => {
    const editorEl = document.querySelector("div.ql-editor");
    if (!editorEl) { resolve(false); return; }
    const currentText = editorEl.textContent.trim();
    let expectedTextLength = 0;
    if (expectedHtml) {
      const tmp = document.createElement("div");
      tmp.innerHTML = expectedHtml;
      expectedTextLength = tmp.textContent.trim().length;
    }
    const MINIMUM_REAL_CONTENT_LENGTH = 200;
    if (expectedTextLength < MINIMUM_REAL_CONTENT_LENGTH) { resolve(false); return; }
    const minimumExpected = Math.max(Math.round(expectedTextLength * 0.3), 50);
    resolve(currentText.length >= minimumExpected);
  });
}

function findFilePondDropZone() {
  return (
    document.querySelector(".filepond--drop-label") ||
    document.querySelector(".filepond--root") ||
    document.querySelector('[class*="filepond--browser"]')?.closest(".filepond--root")
  );
}

async function clickSaveDraft() {
  const btn = findElement(ARTICLE_SELECTORS.saveDraft);
  if (btn) { btn.click(); return true; }
  const draftBtn = findByText("button", ["حفظ كمسودة", "مسودة", "Save Draft", "Draft"]);
  if (draftBtn) { draftBtn.click(); return true; }
  return false;
}

function findByText(selector, texts) {
  const elements = document.querySelectorAll(selector);
  for (const el of elements) {
    const t = el.textContent.trim();
    if (texts.some((txt) => t.includes(txt))) return el;
  }
  return null;
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

// =====================================================
// ── ZID (زد) ──
// =====================================================

// ── رفع صورة الغلاف في زد ──
async function zidUploadImage(imageBase64, imageName) {
  try {
    await sleep(4000);

    const fileInput = document.querySelector('input[type="file"][accept*="image"]');
    if (!fileInput) return { ok: false, error: 'Could not find the image field' };

    const res = await fetch(imageBase64);
    const blob = await res.blob();
    const file = new File([blob], imageName || 'cover.jpg', { type: blob.type || 'image/jpeg' });

    const dt = new DataTransfer();
    dt.items.add(file);
    fileInput.files = dt.files;
    fileInput.dispatchEvent(new Event('change', { bubbles: true }));

    // انتظر محرر الصور يظهر
    await sleep(3000);

    // اضغط "استخدام الصورة الأصلية" لو ظهر
    const useOriginalBtn = Array.from(document.querySelectorAll('button'))
      .find(b => b.textContent?.trim().includes('استخدام الصورة الأصلية') ||
                 b.textContent?.trim().includes('استخدام الحجم الأصلي'));
    if (useOriginalBtn) {
      useOriginalBtn.click();
      await sleep(2000);
    }

    // اضغط حفظ
    const saveBtn = Array.from(document.querySelectorAll('button'))
      .find(b => b.textContent?.trim() === 'حفظ');
    if (saveBtn) {
      saveBtn.click();
      await sleep(2000);
      return { ok: true };
    }

    return { ok: false, error: 'Could not find the save button' };
  } catch(e) {
    return { ok: false, error: e.message };
  }
}
