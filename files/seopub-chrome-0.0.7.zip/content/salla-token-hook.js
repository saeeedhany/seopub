// ===================================================
// Salla Token Hook — يشتغل في MAIN world على s.salla.sa
// بيلقط Authorization من ريكوستات الداشبورد لـ api.salla.dev
// ويحفظه في ذاكرة الصفحة فقط
// ===================================================
(() => {
  if (window.__sallaHookInstalled) return;
  window.__sallaHookInstalled = true;

  const isApi = (u) => {
    try { return /(^|\.)salla\.dev$/.test(new URL(u, location.href).hostname); }
    catch (e) { return false; }
  };

  const grab = (h) => {
    try {
      if (!h) return;
      let v = null;
      if (h instanceof Headers) v = h.get('authorization');
      else if (Array.isArray(h)) v = (h.find(([k]) => String(k).toLowerCase() === 'authorization') || [])[1];
      else v = h['authorization'] || h['Authorization'];
      if (v && /^bearer\s+\S+/i.test(v)) window.__sallaAuth = v;
    } catch (e) {}
  };

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    try {
      const url = input instanceof Request ? input.url : String(input);
      if (isApi(url)) {
        if (input instanceof Request) grab(input.headers);
        if (init) grab(init.headers);
      }
    } catch (e) {}
    return origFetch.apply(this, arguments);
  };

  const origOpen = XMLHttpRequest.prototype.open;
  const origSet = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (m, u) { this.__sallaUrl = String(u); return origOpen.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
    if (String(k).toLowerCase() === 'authorization' && isApi(this.__sallaUrl || '') && /^bearer\s+\S+/i.test(v || '')) {
      window.__sallaAuth = v;
    }
    return origSet.apply(this, arguments);
  };
})();